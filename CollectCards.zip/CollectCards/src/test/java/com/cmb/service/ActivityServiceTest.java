package com.cmb.service;

import com.cmb.dal.entity.Activity;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * @author lingjieshi
 * @version 1: ActivityServiceTest.java, v 0.1 2020/8/13 5:34 下午  lingjieshi Exp $
 */
@SpringBootTest
public class ActivityServiceTest {

    @Autowired
    ActivityService activityService;

    Activity activity = new Activity();

    @Test
    public void addActivity() {
        activity.setName("activity7");
        activity.setPoster("1234");
        activity.setStartTime(new Date());
        activity.setEndTime(new Date());
        activity.setJoinedNumber(929);
        activityService.addActivity(activity);
    }
    @Test
    public void mainActivity() {
        Activity activity1 = activityService.getById(2002);

        List<Activity> activity3 = activityService.getAllActivities();
        activityService.deleteActivity(2002);

        for (Activity a2: activity3){
            System.out.println(a2.getName());
        }
    }
    @Test
    public  void updateById(){
        Activity activity1 = activityService.getById(2002);
        activity1.setAlive(1);
        activity1.setCreateDate(new Date());
        activityService.updateActivity(activity1);
    }

    @Test
    public  void getByName(){
        List<Activity> list = activityService.getActivityListByLikeName("小");
        for (Activity a: list){
            System.out.println(a.getName()+a.getId()+a.getRule());
        }

    }
    @Test
    public  void getAllUpStatusActivities(){
        List<Activity> list = activityService.getAllUpStatusActivities();
        for (Activity a: list){
            System.out.println(a.getName()+a.getId()+a.getRule());
        }
    }
    @Test
    public  void getDownStatusActivities(){
        List<Activity> list = activityService.getDownStatusActivities();
        for (Activity a: list){
            System.out.println(a.getName()+a.getId()+a.getRule());
        }
    }
    @Test
    public  void joined(){
    Activity activity = activityService.getById(2060);
    if (activity.getJoinedNumber()== null){
        activity.setJoinedNumber(1);
        activityService.updateActivity(activity);
    }else{
        activity.setJoinedNumber(activity.getJoinedNumber()+1);
        activityService.updateActivity(activity);
    }
    }

    @Test
    public  void getByTime()throws ParseException {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
      //  String startTime = "2020-08-26 13:37:32";
        String startTime2 = "Mon Aug 31 2020 00:00:00 GMT+0800 (中国标准时间)";
       // Date date = dateFormat.parse(startTime2);

        startTime2 = startTime2.replace("GMT", "").replaceAll("\\(.*\\)", "");
        SimpleDateFormat format =  new SimpleDateFormat("EEE MMM dd yyyy hh:mm:ss z", Locale.ENGLISH);
        Date date = format.parse(startTime2);
        List<Activity> list = activityService.getActivityByCreateTime(date);
        for (Activity a: list){
            System.out.println(a.getName()+a.getId()+a.getRule());
        }

    }

}
