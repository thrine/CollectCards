package com.cmb.service;

import com.cmb.dal.entity.ActiveActivity;

import com.cmb.dal.entity.Card;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

/**
 * @author lingjieshi
 * @version 1: ActiveActivityServiceTest.java, v 0.1 2020/8/20 8:57 上午  lingjieshi Exp $
 */
@SpringBootTest
public class ActiveActivityServiceTest {

    @Autowired
    ActiveActivityService activeActivityService;

    @Test
    public void addUALog(){
        Integer user_id = 1036;
        Integer activity_id = 2001;
        activeActivityService.addUserByActivityId(user_id, activity_id);
        activeActivityService.addUserByActivityId(user_id, activity_id+1);
        activeActivityService.addUserByActivityId(user_id+1, activity_id);
        activeActivityService.addUserByActivityId(user_id+1, activity_id+1);
    }

    @Test
    public void getByUserId(){
        Integer id = 1036;
        List<ActiveActivity> list = activeActivityService.getByUserId(id);
        for (ActiveActivity ac: list){
            System.out.println(ac.getRemainTimes());
        }
    }

    @Test
    public void getByActivityId(){
        Integer id = 2001;
        List<ActiveActivity> list = activeActivityService.getByActivityId(id);
        for (ActiveActivity ac: list){
            System.out.println(ac.getId());
        }
    }

    @Test
    public  void getRemainTimes(){
        Integer user_id = 1036;
        Integer activity_id = 2001;
        Integer times = activeActivityService.getRemainTimes(user_id, activity_id);
        System.out.println(times);
    }

    @Test
    public  void getLOG(){
        Integer user_id = 1034;
        Integer activity_id = 2001;
        ActiveActivity activelog = activeActivityService.getActiveLogByUserAndActivityId(user_id, activity_id);
        System.out.println(activelog.getId());
    }

    @Test
    public void updateRemain(){
        Integer user_id = 1034;
        Integer activity_id = 2001;
        ActiveActivity activeLog = activeActivityService.getActiveLogByUserAndActivityId(user_id, activity_id);
        System.out.println(activeLog.getId());
        ActiveActivity activeActivity = activeActivityService.getActiveLogByUserAndActivityId(user_id+1,activity_id);
        int newRemainTimes = activeActivity.getRemainTimes()-1;
        activeActivity.setRemainTimes(newRemainTimes);
        activeActivityService.updateActiveActivity(activeActivity);
    }
    @Test
    public void updateLog(){

    }
    @Test
    public void updateStatus(){

    }

    public ActiveActivityServiceTest() {
    }


}
