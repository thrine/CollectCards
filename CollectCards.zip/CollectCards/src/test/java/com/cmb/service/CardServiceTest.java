package com.cmb.service;

import com.cmb.dal.entity.Card;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

/**
 * @author lingjieshi
 * @version 1: CardServiceTest.java, v 0.1 2020/8/14 1:43 下午  lingjieshi Exp $
 */
@SpringBootTest
public class CardServiceTest {

    @Autowired
    CardService cardService;

    Card card = new Card();

    @Test
    public void addCard() {
        card.setName("card100");
        card.setPicture("123");
        card.setProbability(0.2);
        card.setActivityId(2002);
        cardService.addCard(card);
    }
    @Test
    public void mainCard() {
        Card card1 = cardService.getById(303);
        List<Card> cards = cardService.getAllCards();
        cardService.deleteCard(card1.getId());
        System.out.println("//");
        for (Card card: cards){
            System.out.println(card.getName());
        }
    }
    @Test
    public  void updateById(){
        Card card1 = cardService.getById(303);
        card1.setAlive(1);
        card1.setName("card2");
        cardService.updateCard(card1);
    }

    @Test
    public  void getFiveCardList(){
        List<Card> cards = cardService.getFiveCardsByActivityId(2001);
        for (Card card: cards){
            System.out.println(card.getName());
        }
    }
}
