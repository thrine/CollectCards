package com.cmb.service;

import com.cmb.dal.entity.UserTest;
//import com.cmb.util.MD5Util;
import com.cmb.model.BaseResult;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.util.DigestUtils;

import java.util.List;

/**
 * @author lingjieshi
 * @version 1: UserServiceTest.java, v 0.1 2020/8/12 1:47 下午  lingjieshi Exp $
 */
@SpringBootTest()
public class UserServiceTest {

    @Autowired
    UserService userService;

    UserTest user = new UserTest();

    @Test
    public void addUser() {
        user.setName("shelley");
        user.setPassword("1234");
        user.setNickname("yang");
        user.setSex("女");
        user.setTelephone("1234567890");
        //对密码进行 md5 加密
        //user.setPassword(MD5Util.MD5EncodeUtf8(user.getPassword()));
        //String md5Password = DigestUtils.md5DigestAsHex(user.getPassword().getBytes());
        //user.setPassword(md5Password);
        userService.addUser(user);
    }
    @Test
    public void deleteUser() {
        userService.deleteUser(1024);
    }

    @Test
    public void password() {
        String  password = DigestUtils.md5DigestAsHex("1234".getBytes());
        System.out.println(password);
    }

    @Test
    public void getUserList() {
        userService.getUserList();
    }

    @Test
    public void login() {
        UserTest user1   = userService.login("shi","1234");
        System.out.println(user1.getId()+" "+user1.getNickname());
    }

    @Test
    public void userLogin() {
        UserTest user1   = userService.FindById(1034);
        System.out.println(user1.getId()+" "+user1.getName()+" "+user1.getPassword());
        user1.setPassword("1234");
        BaseResult user2   = userService.userLogin(user1);
        System.out.println(user2.getMessage()+" "+user2.getData());
    }


    @Test
    public void FindById() {
        UserTest user1   = userService.FindById(1028);
        System.out.println(user1.getId()+" "+user1.getName());
    }

    @Test
    public void FindByName() {
        UserTest user2   = userService.FindByName("md5");
        System.out.println(user2);
    }
    @Test
    public  void updateById(){
    }

    @Test
    public void editUserPassword() {
    }
}

