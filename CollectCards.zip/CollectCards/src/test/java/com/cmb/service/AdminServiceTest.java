package com.cmb.service;

import com.cmb.dal.entity.Admin;
import com.cmb.dal.entity.UserTest;
import com.cmb.model.BaseResult;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.util.DigestUtils;

/**
 * @author lingjieshi
 * @version 1: AdminServiceTest.java, v 0.1 2020/8/13 12:26 下午  lingjieshi Exp $
 */
@SpringBootTest
public class AdminServiceTest {

    @Autowired
    AdminService adminService;

    Admin admin = new Admin();

    @Test
    public void addAdmin(){
        admin.setName("admin");
        admin.setPassword("1234");
        adminService.addAdmin(admin);
    }

    @Test
    public void adminLogin(){
        String name = "manager";
        String password = "1234";
       // String md5PasswordLogin = DigestUtils.md5DigestAsHex(password.getBytes());
        BaseResult  admin1 = adminService.adminLogin(name,password);
        System.out.println(admin1.getMessage()+' '+admin1.getData()+' '+admin1.getCode());
    }

    @Test
    public void getByIdName(){
        Admin admin1 = adminService.getById(24);
        Admin admin2 = adminService.getByName("admin");
        System.out.println(admin1.getName()+' '+admin2.getId());
    }



}
