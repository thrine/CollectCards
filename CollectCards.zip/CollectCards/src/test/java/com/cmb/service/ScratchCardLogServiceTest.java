package com.cmb.service;

import com.cmb.dal.entity.ActiveActivity;
import com.cmb.dal.entity.ScratchCardLog;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Date;
import java.util.List;

/**
 * @author lingjieshi
 * @version 1: ScratchCardLogServiceTest.java, v 0.1 2020/8/20 9:38 上午  lingjieshi Exp $
 */

@SpringBootTest
public class ScratchCardLogServiceTest {

    @Autowired
    ScratchCardLogService scratchCardLogService;

    @Test
    public void addLog(){
        Integer user_id = 1035;
        Integer activity_id = 2002;
        Integer luckyCardId =312;
        ScratchCardLog scratchCardLog = new ScratchCardLog();
        scratchCardLog.setUserId(user_id);
        scratchCardLog.setActivityId(activity_id);
        scratchCardLog.setCardId(luckyCardId);
        scratchCardLog.setGetTime(new Date());
        scratchCardLog.setCardNumber(1);
        scratchCardLogService.addScratchCardLog(scratchCardLog);
    }

    @Test
    public void findLog(){
        Integer userId = 1034;
        Integer activity_id = 2002;
        Integer CardId =306;
        scratchCardLogService.findByUserAndCard(userId,CardId);
        List<ScratchCardLog> list =scratchCardLogService.findByActivityId(activity_id);
        for (ScratchCardLog sc: list){
            System.out.println(sc.getId());
        }
    }

    @Test
    public void NewLogByUC(){
        Integer userId = 1034;
        Integer activity_id = 2002;
        Integer CardId =313;
        ScratchCardLog oddScratchCardLog= scratchCardLogService.findByUserAndCard(userId,CardId);
        if(oddScratchCardLog == null){
        ScratchCardLog scratchCardLog = new ScratchCardLog();
        scratchCardLog.setUserId(userId);
        scratchCardLog.setActivityId(activity_id);
        scratchCardLog.setCardId(CardId);
        scratchCardLog.setGetTime(new Date());
        scratchCardLog.setCardNumber(1);
        scratchCardLogService.addScratchCardLog(scratchCardLog);
        }else {
            oddScratchCardLog.setCardNumber(oddScratchCardLog.getCardNumber()+1);
            scratchCardLogService.updateCardNum(oddScratchCardLog);
        }
    }

    @Test
    public void updateLogByUC() {

    }

    @Test
    public void updateLogByActivity() {

    }

    public ScratchCardLogServiceTest() {
    }


}
