package com.cmb.controller;

import org.junit.Test;

/**
 * @author lingjieshi
 * @version 1: UserControllerTest.java, v 0.1 2020/8/13 1:33 上午  lingjieshi Exp $
 */



        //import com.cmb.dal.entity.pojo.Admin;
        //import com.cmb.service.AdminService;
        import com.cmb.service.UserService;
        //import com.cmb.util.Page;
        import org.junit.Assert;
        import org.junit.Before;
        import org.junit.Test;
        import org.mockito.InjectMocks;
        import org.mockito.Mock;
        import org.mockito.Mockito;
        import org.mockito.MockitoAnnotations;
        import org.springframework.mock.web.MockHttpServletRequest;
        import org.springframework.ui.Model;

        import javax.servlet.http.HttpServletRequest;
        import javax.servlet.http.HttpSession;

        import static org.junit.Assert.*;
        import static org.mockito.Matchers.any;

public class UserControllerTest{

//    @Mock
//    private AdminService adminService;
    @Mock
    private UserService userService;

//    @InjectMocks
//    AdminController adminController;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }
//    @Test
//    public void adminLogin() {
//        String s = adminController.adminLogin();
//        Assert.assertEquals("admin/login", s);
//    }
//
//    @Test
//    public void adminlogin() {
//        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
//        Mockito.when(adminService.queryForLogin(any(String.class),any(String.class))).thenReturn(new Admin());
//        String s = adminController.adminLogin(httpServletRequest,any(HttpSession.class));
//        Assert.assertEquals("admin/adminHome",s);
//    }

//    @Test
//    public void logout() {
//        HttpSession httpSession = Mockito.mock(HttpSession.class);
//        httpSession.setAttribute("admin",new Admin());
//        String s = adminController.logout(httpSession);
//        Assert.assertEquals("redirect:/admin/adminLogin", s);
//    }
//
//    @Test
//    public void getUserList() {
//        Model mode = Mockito.mock(Model.class);
//        Page page = Mockito.mock(Page.class);
//        Mockito.when(userService.getUserList()).thenReturn(null);
//        String s = adminController.getUserList(mode,page);
//        Assert.assertEquals("admin/listUser",s);
//    }
//
//    @Test
//    public void deleteUser() {
//        String s = adminController.deleteUser(any(Integer.class));
//        Assert.assertEquals("redirect:/admin/getUserList",s);
//    }

//    @Test
//    public void addUser() {
//        String s = adminController.addUser();
//        Assert.assertEquals("admin/addUser",s);
//    }
//
//

    @Test
    public void add_user() {
    }


}