package com.cmb.controller;

import org.springframework.boot.test.context.SpringBootTest;

/**
 * @author lingjieshi
 * @version 1: ActivityControllerTest.java, v 0.1 2020/8/21 5:01 下午  lingjieshi Exp $
 */
@SpringBootTest
public class ActivityControllerTest {

    public ActivityControllerTest() {
    }


}
