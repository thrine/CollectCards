package com.cmb.util;

import com.cmb.dal.entity.Card;
import com.cmb.model.CardOffset;
import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author lingjieshi
 * @version 1: ScratchCardUtilTest.java, v 0.1 2020/8/18 5:03 下午  lingjieshi Exp $
 */
@SpringBootTest
public class ScratchCardUtilTest {

    @Test
    public void ScratchCard() {

        Integer allAmount = 10000;// 总配额（抽奖总次数）
        List<Card> cardList = new ArrayList<>();
        cardList.add(new Card(1, "卡1", 0.05));
        cardList.add(new Card(2, "卡2", 0.09));
        cardList.add(new Card(3, "卡3", 0.22));
        cardList.add(new Card(4, "卡4", 0.38));
        cardList.add(new Card(5, "卡5", 0.18));

   // Map<Integer, CardOffset> CardOffsetMap = new HashMap<>();
        Map<Integer, CardOffset> CardOffsetMap = ScratchCardUtil.lotterySpan( allAmount, cardList);

        // log
        for (Integer CardId : CardOffsetMap.keySet()) {
            CardOffset offset = CardOffsetMap.get(CardId);
            System.out.println("卡片: " + CardId + ", 该卡种配额数量: " + offset.getAmount() + ", 占比（生成概率）: " + offset.getPercent() + ", 转盘区间跨度: " + offset.getSpan() + ", 区间: [" + offset.getStart() + ", " + offset.getEnd() + ")");
        }
        //因库存为空，则递归循环刮卡
        Integer CardId = ScratchCardUtil.scratchCard(CardOffsetMap);
        System.out.println(CardId);

        //初次刮卡
        System.out.println( ScratchCardUtil.select(CardOffsetMap));


    }

    @Test
    public void Count(){ Integer allAmount = 12345;// 总配额（抽奖总次数）
        List<Card> cardList = new ArrayList<>();
        cardList.add(new Card(1, "卡1", 0.05));
        cardList.add(new Card(2, "卡2", 0.09));
        cardList.add(new Card(3, "卡3", 0.12));
        cardList.add(new Card(4, "卡4", 0.48));
        cardList.add(new Card(5, "卡5", 0.18));

        // Map<Integer, CardOffset> CardOffsetMap = new HashMap<>();
        Map<Integer, CardOffset> CardOffsetMap = ScratchCardUtil.lotterySpan( allAmount, cardList);
        Map<Integer, Integer> countMap = ScratchCardUtil.countCards( allAmount, CardOffsetMap);

         for (Integer key : countMap.keySet()) {
            System.out.println("卡片"+key + "被抽中了： " + countMap.get(key) + "次，实际被抽到的概率: " + ScratchCardUtil.getPercent(countMap.get(key), allAmount));
         }
        System.out.println( ScratchCardUtil.select(CardOffsetMap));



    }


}
