package com.cmb.enums;

import lombok.Getter;
import lombok.Setter;

/**
 * @author lingjieshi
 * @version 1: ResultCodeEnum.java, v 0.1 2020/8/18 10:55 上午  lingjieshi Exp $
 */

public enum ResultCodeEnum {

    SUCCESS(200, "操作成功"),
    FAILED(500, "操作失败"),
    VALIDATE_FAILED(404, "参数检验失败"),
    UNAUTHORIZED(401, "暂未登录或token已经过期"),
    FORBIDDEN(403, "没有相关权限");
    private int code;
    private String message;


    ResultCodeEnum(int code, String message) {
        this.code = code;
        this.message = message;
    }

    public Integer getCode() {
        return code;
    }
    public void setCode(Integer code){
        this.code = code;
    }

    public String getMessage() {
        return message;
    }
    public void setMsg(String message){
        this.message = message;
    }





}
