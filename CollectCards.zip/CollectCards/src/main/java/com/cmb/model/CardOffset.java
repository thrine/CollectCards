package com.cmb.model;

/**
 * @author lingjieshi
 * @version 1: CardOffset.java, v 0.1 2020/8/18 3:41 下午  lingjieshi Exp $
 */
public class CardOffset {

    public CardOffset() {
    }

    private double percent;
    private int span;
    private int start;
    private int end;
    private int amount;

    public CardOffset(double percent, int span, int start, int end, int amount) {
        this.percent = percent;
        this.span = span;
        this.start = start;
        this.end = end;
        this.amount = amount;
    }

    public double getPercent() {
        return percent;
    }

    public void setPercent(double percent) {
        this.percent = percent;
    }

    public int getSpan() {
        return span;
    }

    public void setSpan(int span) {
        this.span = span;
    }

    public int getStart() {
        return start;
    }

    public void setStart(int start) {
        this.start = start;
    }

    public int getEnd() {
        return end;
    }

    public void setEnd(int end) {
        this.end = end;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

}
