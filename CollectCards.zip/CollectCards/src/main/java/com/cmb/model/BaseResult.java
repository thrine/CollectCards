package com.cmb.model;

/**
 * @author lingjieshi
 * @version 1: BaseResult.java, v 0.1 2020/8/18 10:05 上午  lingjieshi Exp $
 */

import com.cmb.enums.ResultCodeEnum;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * 向前端返回信息封装
 * @param <T> 可变类型
 */

@Getter
@Setter
public class BaseResult<T> implements Serializable {

    //返回信息
    private String message;
    //数据是否正常请求
    private boolean success;
    //返回信息码
    private int code;
    //具体返回的数据
    private T data;

    public BaseResult(){
    }
    protected BaseResult(T data, int code,String message ){
        this.message = message;
        this.code = code;
        this.data = data;
    }
    private BaseResult(boolean success, int code, String message) {
        this.success = success;
        this.code = code;
        this.message = message;
    }
    public BaseResult(T data, boolean success, int code, String message){
        this.data = data;
        this.success = success;
        this.code = code;
        this.message = message;
    }


    //... getter and setter
    /**
     * 返回失败，code码和msg自定义
     */
    public static <T> BaseResult<T> newInstance(){
        return new BaseResult<T>();
    }

    /**
     * 调用默认成功
     */
    public static <T> BaseResult<T> success(T data){
        return new BaseResult<T>(data, true, 200, "成功！");
    }

//    public static <T> BaseResult<T> success(T data) {
//        BaseResult<T> resp = new BaseResult();
//      //  resp.setCode(ResponseCode.SUCCESS.getCode());
//       // resp.setMessage(ResponseCode.SUCCESS.getMessage());
//        resp.setData(data);
//        return resp;
//    }
    /**
     * 返回默认失败
     */
    public static <T> BaseResult<T> defaultFailure(){
        return new BaseResult<T>(false, 500, "系统内部错误");
    }

    /**
     * 自定义失败一
     */
    public static <T> BaseResult<T> failure(T data, int code, String message){
        return new BaseResult<T>(data, false, code, message);
    }
    /**
     * 自定义失败二
     */
    public static <T> BaseResult<T> failure(  int code, String message){
        return new BaseResult<T>(false, code, message);
    }


    public T getData() {
        return data;
    }
    public BaseResult<T> data(T data) {
        this.data = data;
        return this;
    }

    public boolean getSuccess() {
        return success;
    }
    public BaseResult<T> setSuccess(boolean success) {
        this.success = success;
        return this;
    }

    public int getCode() {
        return code;
    }
    public BaseResult<T> setCode(int code) {
        this.code = code;
        return this;
    }

    public String getMessage() {
        return message;
    }
    public BaseResult<T> message(String message) {
        this.message = message;
        return this;
    }
//    private BaseResult<Long> test() {
//        Long data = 1L;
//        /**
//         * 方式一：创建返回结果实例
//         */
//       // return BaseResult.<Long>newInstance().data(data);
//        /**
//         * 方式二：使用默认的
//         */
//       // return BaseResult.<Long>failure(data, 20, "msg");
//        /**
//         * 方式三
//         */
//        BaseResult<Long> baseResult = BaseResult.newInstance();
//        return baseResult.success(true).code(200);
//    }




}
