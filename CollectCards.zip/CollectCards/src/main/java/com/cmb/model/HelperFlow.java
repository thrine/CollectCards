package com.cmb.model;

import java.util.Date;

public class HelperFlow {
    private Integer id;

    private Integer inviterId;

    private Integer activityId;

    private String inviterNickname;

    private String helperNickname;

    private Date getTime;

    private String activityName;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getInviterId() {
        return inviterId;
    }

    public void setInviterId(Integer inviterId) {
        this.inviterId = inviterId;
    }

    public Integer getActivityId() {
        return activityId;
    }

    public void setActivityId(Integer activityId) {
        this.activityId = activityId;
    }

    public String getInviterNickname() {
        return inviterNickname;
    }

    public void setInviterNickname(String inviterNickname) {
        this.inviterNickname = inviterNickname;
    }

    public String getHelperNickname() {
        return helperNickname;
    }

    public void setHelperNickname(String helperNickname) {
        this.helperNickname = helperNickname;
    }

    public Date getGetTime() {
        return getTime;
    }

    public void setGetTime(Date getTime) {
        this.getTime = getTime;
    }

    public String getActivityName() {
        return activityName;
    }

    public void setActivityName(String activityName) {
        this.activityName = activityName;
    }
}