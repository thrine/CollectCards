package com.cmb.service;

import com.cmb.model.HelperFlow;

import java.util.List;

/**
 * @author lingjieshi
 * @version 1: HelperFlowService.java, v 0.1 2020/8/27 4:04 下午  lingjieshi Exp $
 */

public interface HelperFlowService {

    int addHelpFlow(HelperFlow userHelperFlow);

    List<HelperFlow> getHelperFlowByActivity(Integer user_id, Integer activity_id);

}
