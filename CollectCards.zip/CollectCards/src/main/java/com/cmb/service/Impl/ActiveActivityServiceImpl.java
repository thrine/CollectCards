package com.cmb.service.Impl;

import com.cmb.dal.dao.ActiveActivityMapper;
import com.cmb.dal.entity.ActiveActivity;
import com.cmb.model.BaseResult;
import com.cmb.service.ActiveActivityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

/**
 * @author lingjieshi
 * @version 1: ActiveActivityServiceImpl.java, v 0.1 2020/8/19 4:13 下午  lingjieshi Exp $
 */

@Service
public class ActiveActivityServiceImpl implements ActiveActivityService {

    @Autowired
    ActiveActivityMapper activeActivityMapper;

    @Transactional
    @Override
    public List<ActiveActivity> getByUserId(Integer id){
        return activeActivityMapper.getByUserId(id);
    }

    @Transactional
    @Override
    public List<ActiveActivity> getByActivityId(Integer id){
        return activeActivityMapper.getByActivityId(id);
    }

    @Transactional
    @Override
    public int getRemainTimes(Integer user_id,Integer activity_id){
        ActiveActivity activeActivity = activeActivityMapper.selectByActivityAndUser(user_id,activity_id);
        if(activeActivity == null) return -1;
        return activeActivity.getRemainTimes();
    }

    @Transactional
    @Override
    public ActiveActivity getActiveLogByUserAndActivityId(Integer user_id,Integer activity_id){
        ActiveActivity activeActivity = activeActivityMapper.selectByActivityAndUser(user_id,activity_id);
        return activeActivity;
    }

    @Transactional
    @Override
    //新建关于用户的活动参与记录流水
    public BaseResult addUserByActivityId(Integer user_id, Integer activity_id){
        BaseResult result = new BaseResult();
        try{
            ActiveActivity oddActiveActivity = activeActivityMapper.selectByActivityAndUser(user_id,activity_id);
            if(oddActiveActivity == null) {
                ActiveActivity activeActivity = new ActiveActivity();
                activeActivity.setRemainTimes(3);
                activeActivity.setActivityId(activity_id);
                activeActivity.setUserId(user_id);
                activeActivity.setJointTime(new Date());
                activeActivity.setScratchTimes(0);
                activeActivityMapper.insertSelective(activeActivity);
                result.setMessage("用户参与活动记录流水已生成！");
                result.setSuccess(true);
                result.setData(activeActivity);
            }else {
                result.setMessage("用户已经参与过该活动！");
            }
        }catch (Exception e){
                result.setMessage(e.getMessage());
                e.printStackTrace();
            }
            return result;

    }

    @Transactional
    @Override
    public int updateActiveActivity(ActiveActivity activeActivity){
        return activeActivityMapper.updateByPrimaryKeySelective(activeActivity);
    }



}
