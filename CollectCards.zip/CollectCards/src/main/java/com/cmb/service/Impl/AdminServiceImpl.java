package com.cmb.service.Impl;

import com.cmb.dal.dao.AdminMapper;
import com.cmb.dal.dao.UserTokenMapper;
import com.cmb.dal.entity.Admin;
import com.cmb.dal.entity.UserTest;
import com.cmb.dal.entity.UserToken;
import com.cmb.model.BaseResult;
import com.cmb.service.AdminService;
import com.cmb.util.TokenUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.DigestUtils;

/**
 * @author lingjieshi
 * @version 1: AdminServiceImpl.java, v 0.1 2020/8/13 12:12 下午  lingjieshi Exp $
 */
@Service
public class AdminServiceImpl implements AdminService {
    @Autowired
    AdminMapper adminMapper;

    @Autowired
    UserTokenMapper userTokenMapper;

    @Override
    @Transactional
    public BaseResult adminLogin(String name, String password){
        BaseResult result = new BaseResult();
        String md5Password= DigestUtils.md5DigestAsHex(password.getBytes());
        try {
            Admin exitAdmin = adminMapper.adminLogin(name,md5Password);
            if (exitAdmin == null) {
                result.setCode(500);
                result.setMessage("管理员名或密码输入错误！");
            } else {
                result.setCode(200);
                result.setMessage("登录成功");
                result.setSuccess(true);
                UserToken adminToken = new UserToken();
                adminToken.setUserId(exitAdmin.getId());
                adminToken.setUserName(exitAdmin.getName());
                adminToken.setToken(TokenUtil.generateToken());
                userTokenMapper.insertSelective(adminToken);
                result.setData(adminToken);
            }
        }catch (Exception e){
            result.setMessage(e.getMessage());
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public Admin getById(Integer id){
       return adminMapper.selectByPrimaryKey(id);
    }

    @Override
    @Transactional
    public Admin getByName(String name){
        Admin admin = adminMapper.selectByName(name);
        if(admin != null){
            return admin;
         } else{
            return  null;
        }
    }

    @Override
    public BaseResult addAdmin(Admin admin){
        BaseResult result = new BaseResult();
        result.setSuccess(false);
        result.setData(null);
        String md5Password = DigestUtils.md5DigestAsHex(admin.getPassword().getBytes());
        admin.setPassword(md5Password);
        try{
            Admin exitAdmin = adminMapper.selectByName(admin.getName());
            if (exitAdmin == null){
                adminMapper.insert(admin);
                result.setMessage("注册成功");
                result.setCode(200);
                result.setSuccess(true);
                result.setData(admin);
            }else{
                result.setCode(500);
                result.setMessage("管理员已经存在！");
            }
        } catch (Exception e){
            result.setMessage(e.getMessage());
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public void deleteAdmin(Integer id){
        adminMapper.deleteByPrimaryKey(id);
    }
}

