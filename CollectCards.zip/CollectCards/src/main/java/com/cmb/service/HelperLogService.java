package com.cmb.service;

import com.cmb.dal.entity.HelperLog;

import java.util.List;

/**
 * @author lingjieshi
 * @version 1: HelperLogService.java, v 0.1 2020/8/21 1:33 上午  lingjieshi Exp $
 */
public interface HelperLogService {

    HelperLog getCountByUserHelperActivity(Integer user_id, Integer helper_id,Integer activity_id);

    List<HelperLog> getHelperByActivity(Integer user_id, Integer activity_id);

    int addHelpLog(HelperLog userHelperKey);

    int updateHelperLog(HelperLog record);





}
