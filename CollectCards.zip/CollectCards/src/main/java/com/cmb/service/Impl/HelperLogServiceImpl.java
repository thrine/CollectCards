package com.cmb.service.Impl;

import com.cmb.dal.dao.HelperLogMapper;
import com.cmb.dal.entity.HelperLog;
import com.cmb.service.HelperLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author lingjieshi
 * @version 1: HelperLogServiceImpl.java, v 0.1 2020/8/21 1:33 上午  lingjieshi Exp $
 */
@Service
public class HelperLogServiceImpl implements HelperLogService {

    @Autowired
    HelperLogMapper helperLogMapper;

//    @Transactional
//    public List<HelperLog> getHelperListByIds(int user_id, int activity_id){
//        HelperLog helperLog = new HelperLog();
//
//        return shareViewList;
//    }

    @Override
    public HelperLog getCountByUserHelperActivity(Integer user_id, Integer helper_id,Integer activity_id){
        return helperLogMapper.getByUserHelperActivity(user_id,helper_id,activity_id);

    }

    @Override
    public List<HelperLog>  getHelperByActivity(Integer user_id,Integer activity_id){
        return helperLogMapper.getHelperByActivity(user_id,activity_id);
    }

    @Override
    public int addHelpLog(HelperLog helpLog){
        return helperLogMapper.insertSelective(helpLog);
    }

    @Override
    public int updateHelperLog(HelperLog record){
        return helperLogMapper.updateByPrimaryKeySelective(record);
    }



}
