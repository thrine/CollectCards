package com.cmb.service;

import com.cmb.dal.entity.Card;
import com.cmb.model.BaseResult;

import java.util.List;

/**
 * @author lingjieshi
 * @version 1: CardService.java, v 0.1 2020/8/14 1:02 下午  lingjieshi Exp $
 */


public interface CardService {
    /*
     * 通过卡片id查找
     * */
    Card getById(Integer id);
    /**
     * 通过卡片name查找
     * */
    Card getByName(String name);
    /*
     * 编辑卡片信息
     * */
    int updateCard(Card card);
    /*
     * 添加卡片
     * */
    BaseResult addCard(Card card);
    /*
     * 删除卡片
     * */
    void deleteCard(Integer id);

    void deleteCardByActivity(Integer activity_id);
    /*
     * 得到所有在线卡片
     * */
    List<Card> getAllCards();
    /*
     * 根据活动ID得到5张卡片
     * */
    List<Card> getFiveCardsByActivityId(Integer id);
    //抽卡时所需要传入的参数：activity_id，user_id
    /**
     * 0.活动有效期
     * 1.获得五张卡片的生成概率
     * 2.随机数与卡片匹配决定生成什么卡
     * 3.卡池数量减一
     * 4.将卡片加入数据库
     * 5.生成流水信息
     */
    //
//    Integer scratchCard()
}
