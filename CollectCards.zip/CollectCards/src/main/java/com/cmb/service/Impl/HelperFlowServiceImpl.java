package com.cmb.service.Impl;

import com.cmb.dal.dao.HelperFlowMapper;
import com.cmb.model.HelperFlow;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author lingjieshi
 * @version 1: HelperFlowServiceImpl.java, v 0.1 2020/8/27 4:06 下午  lingjieshi Exp $
 */
@Service
public class HelperFlowServiceImpl {

    @Autowired
    HelperFlowMapper helperFlowMapper;

    int addHelpFlow(HelperFlow helperFlow){

        return helperFlowMapper.insertSelective(helperFlow);
    }

    List<HelperFlow> getHelperFlowByActivity(Integer user_id, Integer activity_id){

        return helperFlowMapper.findByUserAndActivity(user_id,activity_id);

    }


}
