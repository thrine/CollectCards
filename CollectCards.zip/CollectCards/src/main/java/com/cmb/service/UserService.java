package com.cmb.service;

import com.cmb.dal.entity.UserTest;
import com.cmb.model.BaseResult;

import java.util.List;

/**
 * @author lingjieshi
 * @version 1: UserService.java, v 0.1 2020/8/12 12:31 下午  lingjieshi Exp $
 */

public interface UserService {

    /**
     * Insert case.
     *
     * @param user  user
     */
    BaseResult addUser(UserTest user);

    /**
     * delete user.
     *
     * @param id primaryKey
     */
    void deleteUser(Integer id);

    List<UserTest> getUserList();
    /**
     * search user.
     *
     * @param name username
     */
    UserTest FindByName(String name);

    BaseResult userLogin(UserTest user);
    /**
     * login check.
     *
     * @param name username
     * @param password password
     */
    UserTest login(String name,String password);

    /**
     * Gets get user by id.
     *
     @param id the id
      * @return the get user by id
     */
    UserTest FindById(Integer id);

    /**
     * Update user.
     *
     * @param user user
     */
    int updateUser(UserTest user);
    /**
     * edit user password.
     *
     * @param user user
     */
    void editUserPassword(UserTest user);

}
