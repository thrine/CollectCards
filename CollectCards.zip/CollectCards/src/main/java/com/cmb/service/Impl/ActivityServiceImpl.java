package com.cmb.service.Impl;

import com.cmb.dal.dao.ActivityMapper;
import com.cmb.dal.entity.Activity;
import com.cmb.model.BaseResult;
import com.cmb.service.ActivityService;
import com.github.pagehelper.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author lingjieshi
 * @version 1: ActivityServiceImpl.java, v 0.1 2020/8/13 4:03 下午  lingjieshi Exp $
 */
@Service
public class ActivityServiceImpl implements ActivityService {

    @Autowired
    ActivityMapper activityMapper;

    @Override
    public Activity getById(Integer id){
        return activityMapper.selectByPrimaryKey(id);
    }

    @Override
    //精确查询
    public Activity getByName(String name){
        return activityMapper.getByName(name);
    }

    @Override
    //模糊查询
    public List<Activity> getActivitiesByName(String name){
        return activityMapper.selectByName("%"+name+"%");
    }

    @Override
    //根据创建时间查询
    public List<Activity> getActivityByCreateTime(Date startTime){
        return activityMapper.getActivityByCreateTime(startTime);
    }

    @Override
    public BaseResult updateActivity(Activity activity){
        BaseResult result = new BaseResult();
        try {
            Activity oddActivity = activityMapper.selectByPrimaryKey(activity.getId());
            if (oddActivity == null) {
                return BaseResult.failure(500, "该活动不存在！");
            } else {
                activityMapper.updateByPrimaryKeySelective(activity);
                result.setCode(200);
                result.setMessage("活动编辑成功！");
            }
        }catch (Exception e){
                result.setMessage(e.getMessage());
                e.printStackTrace();
            }
            return result;
    }

    @Override
    @Transactional
    public BaseResult addActivity(Activity activity){
        BaseResult result = new BaseResult();
        result.setSuccess(false);
        result.setData(null);
        try{
            //名称不可重复
           // List<Activity> oddActivity = activityMapper.selectByName(activity.getName());
            Activity oddActivity = activityMapper.getByName(activity.getName());
            if(oddActivity == null) {
                activityMapper.insertSelective(activity);
                result.setMessage("活动添加成功！");
                result.setCode(200);
                result.setSuccess(true);
                //为了获取活动id
                Activity newActivity = activityMapper.getByName(activity.getName());
                result.setData(newActivity);
            }else {
                result.setCode(500);
                result.setSuccess(false);
                result.setMessage("该活动名称已经被占用！");
            }
        }catch (Exception e){
            result.setMessage(e.getMessage());
            e.printStackTrace();
        }
        return result;
    }

    @Override
    @Transactional
    public void updateActivityListStatus(List<Integer> activity_idList){
        for (Integer id : activity_idList) {
            String status = activityMapper.selectByPrimaryKey(id).getStatus();
            Activity activity = activityMapper.selectByPrimaryKey(id);
            if(status == null || status.equals("")){
                activity.setStatus("下架");
            } else if(("下架").equals(status)){
                activity.setStatus("");
            }
            activityMapper.updateByPrimaryKeySelective(activity);
        }
    }

    @Override
    @Transactional
    public void updateActivityStatus(Integer activity_id){
       String status = activityMapper.selectByPrimaryKey(activity_id).getStatus();
       Activity activity = activityMapper.selectByPrimaryKey(activity_id);
            if(status == null || status.equals("")){
                activity.setStatus("下架");
            }
            else if(("下架").equals(status)){
                activity.setStatus("");
            }

        activityMapper.updateByPrimaryKeySelective(activity);

    }

    @Override
    public void deleteActivity(Integer activityId){
        try{
            activityMapper.deleteByPrimaryKey(activityId);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public List<Activity> getAllActivities(){
        return activityMapper.getAllActivities();
    }

    @Override
    public List<Activity> getAllUpStatusActivities(){
        List<Activity> activityList = activityMapper.getAllActivities();
        List<Activity> activityListNew = new ArrayList<>();
        for(Activity a : activityList){
            String status = a.getStatus();
            if(status == null || status.equals("")){
                activityListNew.add(a);
            }
        }
        return activityListNew;
    }

    @Override
    public List<Activity> getDownStatusActivities(){
        List<Activity> activityList = activityMapper.getAllActivities();
        List<Activity> activityListNew = new ArrayList<>();
        for(Activity a : activityList){
            String status = a.getStatus();
            if(("下架").equals(status)){
                activityListNew.add(a);
            }
        }
        return activityListNew;
    }

    @Override
    public List<Activity> getActivityListByLikeName(String name){
        return activityMapper.selectByName("%"+name+"%");
    }

}
