package com.cmb.service;

import com.cmb.dal.entity.Admin;
import com.cmb.model.BaseResult;

/**
 * @author lingjieshi
 * @version 1: AdminService.java, v 0.1 2020/8/13 12:10 下午  lingjieshi Exp $
 */

public interface AdminService {

    BaseResult adminLogin(String name, String password);
    BaseResult addAdmin(Admin admin);
    void deleteAdmin(Integer id);
    Admin getByName (String name);
    Admin getById (Integer id);
}
