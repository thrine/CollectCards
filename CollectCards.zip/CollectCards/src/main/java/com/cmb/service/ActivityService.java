package com.cmb.service;

import com.cmb.dal.entity.Activity;
import com.cmb.model.BaseResult;
import com.github.pagehelper.PageHelper;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

/**
 * @author lingjieshi
 * @version 1: ActivityService.java, v 0.1 2020/8/13 3:51 下午  lingjieshi Exp $
 */

public interface ActivityService {
    /**
     * 通过商品id查找活动
     * */
    Activity getById(Integer id);

    /**
     * 通过名称查询活动
     * */
    Activity getByName(String name);
    /**
     * 通过关键词查询活动
     * */
    List<Activity> getActivitiesByName(String name);
    /**
     * 通过有效时间查询活动
     * */
    List<Activity> getActivityByCreateTime(Date time);
    /**
     * 编辑活动信息
     * */
    BaseResult updateActivity(Activity activity);

    void updateActivityListStatus(List<Integer> activity_ids);

    void updateActivityStatus(Integer activity_id);

    /**
     * 添加活动
     * */
    BaseResult addActivity(Activity activity);
    /**
     * 删除活动
     * */
    void deleteActivity(Integer activityId);
    /**
     * 得到所有在线活动
     * */
    List<Activity> getAllActivities();

    List<Activity> getAllUpStatusActivities();

    List<Activity> getDownStatusActivities();

    /**
     * 通过商品id编辑活动上下架状态
     * */


    /**
     * 活动名称的模糊查询
     * */
    List<Activity> getActivityListByLikeName(String name);


}
