package com.cmb.service.Impl;

import com.cmb.dal.dao.ScratchCardLogMapper;
import com.cmb.dal.entity.ScratchCardLog;
import com.cmb.service.ScratchCardLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author lingjieshi
 * @version 1: ScratchCardLogServiceImpl.java, v 0.1 2020/8/20 1:11 上午  lingjieshi Exp $
 */

@Service
public class ScratchCardLogServiceImpl implements ScratchCardLogService {
    @Autowired
    ScratchCardLogMapper scratchCardLogMapper;

    @Override
    public int addScratchCardLog(ScratchCardLog record){
        return scratchCardLogMapper.insertSelective(record);
    }

    @Override
    public List<ScratchCardLog> findByActivityId(Integer activityId){
        return scratchCardLogMapper.findByActivityId(activityId);
    }

    @Override
    public ScratchCardLog findByUserAndCard(Integer userId,Integer cardId){
        return scratchCardLogMapper.findByUserAndCard(userId,cardId);
    }

    @Override
    public List<ScratchCardLog> findByUserAndActivity(Integer userId,Integer activityId){
        return scratchCardLogMapper.findByUserAndActivity(userId,activityId);
    }

    @Override
    public int updateCardNum(ScratchCardLog record){
        return scratchCardLogMapper.updateByPrimaryKeySelective(record);
    }


}
