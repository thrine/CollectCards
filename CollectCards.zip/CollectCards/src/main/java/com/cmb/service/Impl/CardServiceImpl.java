package com.cmb.service.Impl;

import com.cmb.dal.dao.CardMapper;
import com.cmb.dal.entity.Card;
import com.cmb.model.BaseResult;
import com.cmb.service.CardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author lingjieshi
 * @version 1: CardServiceImpl.java, v 0.1 2020/8/14 1:02 下午  lingjieshi Exp $
 */
@Service
public class CardServiceImpl implements CardService {

    @Autowired
    CardMapper cardMapper;

    @Override
    public Card getById(Integer id){
        return cardMapper.selectByPrimaryKey(id);
    }

    @Override
    public Card getByName(String name){
        return cardMapper.selectByName(name);
    }

    @Override
    @Transactional
    public int updateCard(Card card){
        return cardMapper.updateByPrimaryKeySelective(card);
    }

    @Override
    @Transactional
    public BaseResult addCard(Card card){
        BaseResult result = new BaseResult();
        try{
            Card oddActivity = cardMapper.selectByName(card.getName());
            if(oddActivity == null) {
                cardMapper.insertSelective(card);
                result.setMessage("卡片添加成功！");
                result.setCode(200);
                result.setSuccess(true);
                result.setData(card);
            }else {
                result.setCode(500);
                result.setSuccess(false);
                result.setMessage("该卡片名称已经被占用！");
            }
        }catch (Exception e){
            result.setMessage(e.getMessage());
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public void deleteCard(Integer id){
        try{
            cardMapper.deleteByPrimaryKey(id);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public void deleteCardByActivity(Integer activity_id){
        cardMapper.deleteCardByActivity(activity_id);
    }

    @Override
    public List<Card> getAllCards(){
        return cardMapper.getAllCards();
    }

    @Override
    public List<Card> getFiveCardsByActivityId(Integer id){
        return cardMapper.getFiveCardsByActivityId(id);
    }

}
