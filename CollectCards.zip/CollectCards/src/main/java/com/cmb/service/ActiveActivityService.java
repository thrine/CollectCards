package com.cmb.service;

import com.cmb.dal.entity.ActiveActivity;
import com.cmb.model.BaseResult;

import java.util.List;

/**
 * @author lingjieshi
 * @version 1: ActiveActivityService.java, v 0.1 2020/8/19 4:13 下午  lingjieshi Exp $
 */

public interface ActiveActivityService {

    List<ActiveActivity> getByUserId(Integer id);

    List<ActiveActivity> getByActivityId(Integer id);

    int getRemainTimes(Integer user_id,Integer activity_id);

    ActiveActivity getActiveLogByUserAndActivityId(Integer user_id,Integer activity_id);

    //ActiveActivity selectByActivityAndUser(Integer user_id,Integer activity_id);

    //ActiveActivity getUserByActivityId(Integer user_id,Integer activity_id);

   // int updateRemainTimesByKey(int origin_times, ActiveActivity join);

    int updateActiveActivity(ActiveActivity activeActivity);

    BaseResult addUserByActivityId(Integer user_id, Integer activity_id);

   // int updateCompleteStatus(int user_id,int value);



}
