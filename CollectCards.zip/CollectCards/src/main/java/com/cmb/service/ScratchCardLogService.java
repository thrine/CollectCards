package com.cmb.service;

import com.cmb.dal.entity.ScratchCardLog;

import java.util.List;

/**
 * @author lingjieshi
 * @version 1: ScratchCardLogService.java, v 0.1 2020/8/20 1:10 上午  lingjieshi Exp $
 */

public interface ScratchCardLogService {

    int addScratchCardLog(ScratchCardLog record);

    ScratchCardLog findByUserAndCard(Integer user_id,Integer card_id);

    List<ScratchCardLog> findByActivityId(Integer activity_id);

    List<ScratchCardLog> findByUserAndActivity(Integer user_id,Integer activity_id);

    int updateCardNum(ScratchCardLog record);


}
