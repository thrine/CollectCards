package com.cmb.service.Impl;

import com.cmb.dal.dao.UserTestMapper;
import com.cmb.dal.dao.UserTokenMapper;
import com.cmb.dal.entity.UserTest;
import com.cmb.dal.entity.UserToken;
import com.cmb.model.BaseResult;
import com.cmb.service.UserService;
import com.cmb.util.TokenUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.DigestUtils;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author lingjieshi
 * @version 1: UserServiceImpl.java, v 0.1 2020/8/12 12:34 下午  lingjieshi Exp $
 */

@Service
//@Transactional(rollbackFor = RuntimeException.class）
public class UserServiceImpl implements UserService {

    @Autowired
    UserTestMapper userMapper;

    @Autowired
    UserTokenMapper userTokenMapper;

    @Override
    public BaseResult addUser(UserTest user) {
        BaseResult result = new BaseResult();
        result.setSuccess(false);
        result.setData(null);
        //MD5:对密码进行 md5 加密
        String md5Password = DigestUtils.md5DigestAsHex(user.getPassword().getBytes());
        user.setPassword(md5Password);
        try{
            UserTest exitUser = userMapper.FindByName(user.getName());
            if (exitUser == null){
                userMapper.insertSelective(user);
                result.setMessage("注册成功");
                result.setCode(200);
                result.setSuccess(true);
                result.setData(user);
            }else{
                result.setCode(500);
                result.setMessage("用户已经存在！");
            }
        } catch (Exception e){
            result.setMessage(e.getMessage());
            e.printStackTrace();
        }
        return result;
    }
    @Override
    public BaseResult userLogin(UserTest user) {
        BaseResult result = new BaseResult();
        result.setSuccess(false);
        result.setData(null);
        //md5 对密码进行解密验证
        String md5Password= DigestUtils.md5DigestAsHex(user.getPassword().getBytes());
        user.setPassword(md5Password);
        try {
            UserTest exitUser = userMapper.login(user.getName(),md5Password);
            if (exitUser == null) {
                result.setCode(500);
                result.setMessage("用户名或密码输入错误！");
            } else {
                UserToken userToken = new UserToken();
                userToken.setUserId(exitUser.getId());
                userToken.setUserName(exitUser.getName());
                userToken.setToken(TokenUtil.generateToken());
                userTokenMapper.insertSelective(userToken);
                result.setMessage("登录成功");
                result.setCode(200);
                result.setSuccess(true);
                user.setId(exitUser.getId());
                result.setData(userToken);
            }
        }catch (Exception e){
                result.setMessage(e.getMessage());
                e.printStackTrace();
            }
            return result;
    }

    @Override
    public UserTest login(String name,String password) {
        String md5Password= DigestUtils.md5DigestAsHex(password.getBytes());
        return userMapper.login(name, md5Password);
    }

    @Override
    public void deleteUser(Integer id) {
        userMapper.deleteByKey(id);
    }

    @Override
    public List<UserTest> getUserList() {
        return userMapper.getUserList();
    }

    @Override
    public UserTest FindById(Integer id) {
        return userMapper.FindById(id);
    }

    @Transactional
    @Override
    public int updateUser(UserTest user) {
        return userMapper.updateByPrimaryKeySelective(user);
    }

    @Override
    public void editUserPassword(UserTest user) {
        userMapper.editUserPassword(user);
    }

    @Transactional
    @Override
    public UserTest FindByName(String name) {
        UserTest user = userMapper.FindByName(name);
        if(user != null){
            return user;
        } else{
            return  null;
        }
    }
}
