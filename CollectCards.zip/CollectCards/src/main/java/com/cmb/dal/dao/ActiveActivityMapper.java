package com.cmb.dal.dao;

import com.cmb.dal.entity.ActiveActivity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface ActiveActivityMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(ActiveActivity record);

    int insertSelective(ActiveActivity record);

    ActiveActivity selectByPrimaryKey(Integer id);

    ActiveActivity selectByActivityAndUser(@Param("user_id")Integer user_id, @Param("activity_id")Integer activity_id);

    List<ActiveActivity> getByUserId(Integer id);

    List<ActiveActivity> getByActivityId(Integer id);

    int updateByPrimaryKeySelective(ActiveActivity record);

    int updateByPrimaryKey(ActiveActivity record);
}
