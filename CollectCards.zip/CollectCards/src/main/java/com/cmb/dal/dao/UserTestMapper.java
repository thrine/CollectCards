package com.cmb.dal.dao;

import com.cmb.dal.entity.UserTest;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface UserTestMapper {

    void insert(UserTest record);

    void deleteByKey(Integer id);

    List<UserTest> getUserList();

    UserTest login(@Param("name")String name, @Param("password")String password);

    UserTest userLogin(UserTest record);

    int insertSelective(UserTest record);

    UserTest FindById(Integer id);

    UserTest FindByName(String name);

    int updateByPrimaryKeySelective(UserTest record);

    void updateUser(UserTest user);

    void editUserPassword(UserTest user);

}
