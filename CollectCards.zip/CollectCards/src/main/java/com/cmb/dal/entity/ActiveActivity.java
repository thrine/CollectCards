package com.cmb.dal.entity;

import java.util.Date;

public class ActiveActivity {
    private Integer id;

    private Integer userId;

    private Integer activityId;

    private Date jointTime;

    private Integer remainTimes;

    private Integer slot1Num;

    private Integer slot2Num;

    private Integer slot3Num;

    private Integer slot4Num;

    private Integer slot5Num;

    private Integer scratchTimes;

    private Integer alive;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getActivityId() {
        return activityId;
    }

    public void setActivityId(Integer activityId) {
        this.activityId = activityId;
    }

    public Date getJointTime() {
        return jointTime;
    }

    public void setJointTime(Date jointTime) {
        this.jointTime = jointTime;
    }

    public Integer getRemainTimes() {
        return remainTimes;
    }

    public void setRemainTimes(Integer remainTimes) {
        this.remainTimes = remainTimes;
    }

    public Integer getSlot1Num() {
        return slot1Num;
    }

    public void setSlot1Num(Integer slot1Num) {
        this.slot1Num = slot1Num;
    }

    public Integer getSlot2Num() {
        return slot2Num;
    }

    public void setSlot2Num(Integer slot2Num) {
        this.slot2Num = slot2Num;
    }

    public Integer getSlot3Num() {
        return slot3Num;
    }

    public void setSlot3Num(Integer slot3Num) {
        this.slot3Num = slot3Num;
    }

    public Integer getSlot4Num() {
        return slot4Num;
    }

    public void setSlot4Num(Integer slot4Num) {
        this.slot4Num = slot4Num;
    }

    public Integer getSlot5Num() {
        return slot5Num;
    }

    public void setSlot5Num(Integer slot5Num) {
        this.slot5Num = slot5Num;
    }

    public Integer getScratchTimes() {
        return scratchTimes;
    }

    public void setScratchTimes(Integer scratchTimes) {
        this.scratchTimes = scratchTimes;
    }

    public Integer getAlive() {
        return alive;
    }

    public void setAlive(Integer alive) {
        this.alive = alive;
    }
}