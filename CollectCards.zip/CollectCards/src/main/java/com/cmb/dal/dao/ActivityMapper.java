package com.cmb.dal.dao;

import com.cmb.dal.entity.Activity;
import org.apache.ibatis.annotations.Mapper;

import java.util.Date;
import java.util.List;

@Mapper
public interface ActivityMapper {

    void deleteByPrimaryKey(Integer activityId);

    int insert(Activity activity);

    void insertSelective(Activity activity);

    Activity selectByPrimaryKey(Integer id);

    //准确查询
    Activity getByName(String name);

    //模糊查询
    List<Activity> selectByName(String name);

    List<Activity> getActivityByCreateTime(Date time);

    List<Activity> getAllActivities();

    List<Activity> getDownStatusActivities();

    List<Activity> getAllUpStatusActivities();

    int updateByPrimaryKeySelective(Activity activity);

    //void updateByPrimaryKey(Activity activity);

}
