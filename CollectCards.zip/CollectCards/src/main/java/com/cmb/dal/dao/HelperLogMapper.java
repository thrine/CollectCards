package com.cmb.dal.dao;

import com.cmb.dal.entity.HelperLog;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface HelperLogMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(HelperLog record);

    int insertSelective(HelperLog record);

    HelperLog selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(HelperLog record);

    int updateByPrimaryKey(HelperLog record);

    HelperLog getByUserHelperActivity(Integer user_id, Integer helper_id,Integer activity_id);

    List<HelperLog> getHelperByActivity(Integer user_id, Integer activity_id);
}
