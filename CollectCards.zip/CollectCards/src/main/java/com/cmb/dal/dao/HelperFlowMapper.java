package com.cmb.dal.dao;

import com.cmb.model.HelperFlow;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface HelperFlowMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(HelperFlow record);

    int insertSelective(HelperFlow record);

    HelperFlow selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(HelperFlow record);

    int updateByPrimaryKey(HelperFlow record);

    List<HelperFlow> findByUserAndActivity(Integer inviter_id, Integer activity_id);
}
