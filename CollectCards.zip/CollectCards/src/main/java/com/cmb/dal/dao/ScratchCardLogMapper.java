package com.cmb.dal.dao;

import com.cmb.dal.entity.ScratchCardLog;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface ScratchCardLogMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(ScratchCardLog record);

    int insertSelective(ScratchCardLog record);

    ScratchCardLog selectByPrimaryKey(Integer id);

    List<ScratchCardLog> findByActivityId(Integer activity_id);

    List<ScratchCardLog> findByUserAndActivity(Integer user_id,Integer activity_id);

    ScratchCardLog findByUserAndCard(Integer user_id, Integer card_id);

    int updateByPrimaryKeySelective(ScratchCardLog record);

    int updateByPrimaryKey(ScratchCardLog record);

}
