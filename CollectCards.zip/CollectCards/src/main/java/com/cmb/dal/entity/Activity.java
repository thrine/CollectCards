package com.cmb.dal.entity;

import java.util.Date;
import java.util.List;

public class Activity {
    private Integer id;

    private String name;

    private String poster;

    private Date startTime;

    private Date endTime;

    private Date createDate;

    private String creator;

    private String status;

    private String rule;

    private String cardType;

    private Integer cardNumber;//卡片总数

    private Integer joinedNumber;

    private Integer finishedNumber;

    private Integer alive;

    private List<Card> cards;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPoster() {
        return poster;
    }

    public void setPoster(String poster) {
        this.poster = poster;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getRule() {
        return rule;
    }

    public void setRule(String rule) {
        this.rule = rule;
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public Integer getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(Integer cardNumber) {
        this.cardNumber = cardNumber;
    }

    public Integer getJoinedNumber() {
        return joinedNumber;
    }

    public void setJoinedNumber(Integer joinedNumber) {
        this.joinedNumber = joinedNumber;
    }

    public Integer getFinishedNumber() {
        return finishedNumber;
    }

    public void setFinishedNumber(Integer finishedNumber) {
        this.finishedNumber = finishedNumber;
    }

    public Integer getAlive() {
        return alive;
    }

    public void setAlive(Integer alive) {
        this.alive = alive;
    }
}
