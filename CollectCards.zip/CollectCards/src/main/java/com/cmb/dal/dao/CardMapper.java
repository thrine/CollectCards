package com.cmb.dal.dao;

import com.cmb.dal.entity.Card;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface CardMapper {
    void deleteByPrimaryKey(Integer id);

    void deleteCardByActivity(Integer activity_id);

    int insert(Card record);

    int insertSelective(Card record);

    Card selectByPrimaryKey(Integer id);

    Card selectByName(String name);

    int updateByPrimaryKeySelective(Card record);

    //void updateByPrimaryKey(Card record);
    List<Card> getAllCards();

    List<Card> getFiveCardsByActivityId(Integer id);

}
