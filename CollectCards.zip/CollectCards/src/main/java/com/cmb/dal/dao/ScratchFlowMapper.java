package com.cmb.dal.dao;

import com.cmb.model.ScratchFlow;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface ScratchFlowMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(ScratchFlow record);

    int insertSelective(ScratchFlow record);

    ScratchFlow selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(ScratchFlow record);

    int updateByPrimaryKey(ScratchFlow record);

    List<ScratchFlow> findByUserAndActivity(Integer user_id,Integer activity_id);

}
