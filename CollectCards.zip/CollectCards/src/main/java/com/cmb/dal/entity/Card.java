package com.cmb.dal.entity;

public class Card {
    private Integer id;

    private String name;

    private String picture;

    private double probability;

    private String type;

    private Integer activityId;

    private Integer alive;

    public Card(){

    }

    public Card(Integer id, String name, double probability){
        this.id = id;
        this.name = name;
        this.probability = probability;
    }

    public Card(Integer id, String name, double probability, Integer activityId){
        this.id = id;
        this.name = name;
        this.probability = probability;
        this.activityId = activityId;
    }
    public Card(Integer id, String name,String picture, double probability,String type,Integer activityId,Integer alive){
        this.id = id;
        this.name = name;
        this.picture = picture;
        this.probability = probability;
        this.type = type;
        this.activityId = activityId;
        this.alive =alive;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    public double getProbability() {
        return probability;
    }

    public void setProbability(double probability) {
        this.probability = probability;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getActivityId() {
        return activityId;
    }

    public void setActivityId(Integer activityId) {
        this.activityId = activityId;
    }

    public Integer getAlive() {
        return alive;
    }

    public void setAlive(Integer alive) {
        this.alive = alive;
    }
}
