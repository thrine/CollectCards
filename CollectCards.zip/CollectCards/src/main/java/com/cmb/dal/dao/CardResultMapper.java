package com.cmb.dal.dao;

import com.cmb.model.CardResult;

public interface CardResultMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(CardResult record);

    int insertSelective(CardResult record);

    CardResult selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(CardResult record);

    int updateByPrimaryKey(CardResult record);
}