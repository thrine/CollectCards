package com.cmb.controller;

import com.cmb.dal.dao.HelperFlowMapper;
import com.cmb.dal.dao.ScratchFlowMapper;
import com.cmb.dal.dao.UserTokenMapper;
import com.cmb.dal.entity.*;
import com.cmb.model.*;
import com.cmb.service.*;
import com.cmb.util.ScratchCardUtil;
import com.cmb.util.TokenUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.*;

/**
 * @author lingjieshi
 * @version 1: ActivityController.java, v 0.1 2020/8/19 4:10 下午  lingjieshi Exp $
 */

@RestController
@RequestMapping(value = "/activity")
public class ActivityController {

    @Autowired
    ActivityService activityService;

    @Autowired
    CardService cardService;

    @Autowired
    UserService userService;

    @Autowired
    ActiveActivityService activeActivityService;

    @Autowired
    ScratchCardLogService scratchCardLogService;

    @Autowired
    ScratchFlowMapper scratchFlowMapper;

    @Autowired
    HelperFlowMapper helperFlowMapper;

    @Autowired
    UserTokenMapper userTokenMapper;



    /**点击获取所有在线活动列表
     *
     */
    @GetMapping("/getAllActivities")
    @ResponseBody
    public BaseResult getAllActivities(){
        List<Activity> activityList = activityService.getAllActivities();
        return BaseResult.success(activityList);
    }

    /**点击获取所有上架活动列表
     *
     */
    @GetMapping("/getAllUpStatusActivities")
    @ResponseBody
    public BaseResult getAllUpStatusActivities(){
        List<Activity> activityList = activityService.getAllUpStatusActivities();
        return BaseResult.success(activityList);
    }

    /**点击获取所有下架活动列表
     *
     */
    @GetMapping("/getDownStatusActivities")
    @ResponseBody
    public BaseResult getDownStatusActivities(){
        List<Activity> activityList=  activityService.getDownStatusActivities();
        return BaseResult.success(activityList);
    }

    /**点击获取某个在线活动详情
     *
     */
    @GetMapping(value = "/detail/{activityId}")
    @ResponseBody
    public BaseResult getActivityDetail(@PathVariable int activityId){
        Activity activity=activityService.getById(activityId);
        return BaseResult.success(activity);
    }
    @GetMapping(value = "/fiveCards/{activityId}")
    @ResponseBody
    public BaseResult getActivityFiveCards(@PathVariable int activityId){
        List<Card> fiveCardsList =cardService.getFiveCardsByActivityId(activityId);
        if( fiveCardsList.size() > 5){
            return BaseResult.failure(400,"后台卡片信息异常！");
        }
        return BaseResult.success(fiveCardsList);
    }

    /**点击我的活动显示我的活动列表
     *
     */
    @GetMapping(value = "/getMyActivityList")
    @ResponseBody
    public BaseResult getMyActivities(){
        String token = TokenUtil.getRequest().getHeader("Authorization");// 从 http 请求头中取出 token
        Integer userId = userTokenMapper.getByToken(token).getUserId();
        List<ActiveActivity> myActiveActivityList=activeActivityService.getByUserId(userId);
        if(myActiveActivityList.isEmpty()){
            return BaseResult.success("暂无活动参与记录！");
        }
        List<Activity> myActivityList = new ArrayList<>();
        for(ActiveActivity active: myActiveActivityList){
            Activity activity =activityService.getById(active.getActivityId());
            myActivityList.add(activity);
        }
        return BaseResult.success(myActivityList);
    }

    /**点击我的活动显示我的活动列表与卡片数、剩余抽卡数
     *
     */
    @GetMapping(value = "/getMyActivityStatus/{userId}")
    @ResponseBody
    public BaseResult getMyActivityStatus(@PathVariable int userId){
        List<ActiveActivity> myActiveActivityList=activeActivityService.getByUserId(userId);
        return BaseResult.success(myActiveActivityList);
    }

    /**
     * 参加活动，初次参与即获得3次抽卡机会,然后用户根据管理员设定的刮卡概率抽卡
     */
    @PostMapping(value = "/joinActivity")
    @ResponseBody
    public BaseResult joinActivity(@RequestParam(value = "activityId") Integer activityId){
        String token = TokenUtil.getRequest().getHeader("Authorization");// 从 http 请求头中取出 token
        Integer userId = userTokenMapper.getByToken(token).getUserId();
        //查询是否为新用户，若为旧户则获取用户在该活动的剩余刮卡次数，新户剩余次数设为-1
        int remainTimes = activeActivityService.getRemainTimes(userId,activityId);
        //对于新用户，新建活动参与流水
        if (remainTimes<0){
            activeActivityService.addUserByActivityId(userId,activityId);
        }else if(remainTimes==0){
            return BaseResult.failure(500,"您的刮卡机会已用完！");
        }
        /**抽卡
         * 根据活动ID获取活动的总配额 allAmount;
         * 根据活动ID获取卡片列表 @Param： cardList ;
         *   lotterySpan函数：1.获得五张卡片的生成概率
         *                   2.随机数与卡片匹配决定生成什么卡
         *                   3.相应卡种剩余数-1
         */
        Activity activity = activityService.getById(activityId);
        Integer allAmount = activity.getCardNumber();// 总配额（抽奖总次数）
        List<Card> cardList =cardService.getFiveCardsByActivityId(activityId);
        /**根据概率分配抽奖转盘的固定区间 lotterySpan函数：
         *                   1.获得五张卡片的生成概率
         *                   2.配置中奖掉落区间lotterySpan
         *                   3.随机数与卡片匹配决定生成什么卡
         *                   4.相应卡种剩余数-1
         */
        Map<Integer, CardOffset> CardOffsetMap = ScratchCardUtil.lotterySpan( allAmount, cardList);

        /**  刮卡！！！！！！获取卡种Id---luckyCardId
         *   若因相关卡种的库存为空，则递归循环刮卡，有可能轮空（即未中奖），所以为有效循环
         *   轮空设卡片名为落空，卡片ID=-1
         *   剩余刮卡次数-1,并及时更新用户活动记录的状态
         */
        Integer luckyCardId = ScratchCardUtil.scratchCard(CardOffsetMap);
        ActiveActivity activeActivity = activeActivityService.getActiveLogByUserAndActivityId(userId,activityId);
        int newRemainTimes = activeActivity.getRemainTimes()-1;
        activeActivity.setRemainTimes(newRemainTimes);
        activeActivityService.updateActiveActivity(activeActivity);

        if(luckyCardId ==null){
            return BaseResult.failure(000,"卡片已经被抽完了！下次早点来噢！");
        }
        if (luckyCardId == -1){
            //落空，未中奖
            return BaseResult.failure(001,"哎呀，差一点就抽中了，下次加油！！");
        }

        //添加刮卡流水
        ScratchFlow scratchflow = new ScratchFlow();
        scratchflow.setUserId(userId);
        scratchflow.setUserNickname(userService.FindById(userId).getNickname());
        scratchflow.setActivityId(activityId);
        scratchflow.setCardName(cardService.getById(luckyCardId).getName());
        scratchflow.setGetTime(new Date());
        scratchflow.setActivityName(activityService.getById(activityId).getName());
        scratchFlowMapper.insertSelective(scratchflow);

        /**查询用户-卡片记录
         * 如果生成新卡片，1.将卡片加入用户-卡片记录数据表
         *              2.生成刮卡的流水信息,并添加入刮卡记录的数据库。
         * 如果表格存在该条记录，添加该类型卡片数量
         */
        ScratchCardLog oddScratchCardLog= scratchCardLogService.findByUserAndCard(userId,luckyCardId);
        if(oddScratchCardLog == null){
            ScratchCardLog scratchCardLog = new ScratchCardLog();
            scratchCardLog.setUserId(userId);
            scratchCardLog.setActivityId(activityId);
            scratchCardLog.setCardId(luckyCardId);
            scratchCardLog.setGetTime(new Date());
            scratchCardLog.setCardNumber(1);
            scratchCardLogService.addScratchCardLog(scratchCardLog);
        }else{
            oddScratchCardLog.setCardNumber(oddScratchCardLog.getCardNumber()+1);
            scratchCardLogService.updateCardNum(oddScratchCardLog);
        }
        //查询已有卡片数量
        List<ScratchCardLog> cardLogs = scratchCardLogService.findByUserAndActivity(userId,activityId);
        if(cardLogs.size() == 5){
            //更新活动完成人数的状态
            if (activity.getFinishedNumber()== null){
                activity.setFinishedNumber(1);
            }else{
                activity.setFinishedNumber(activity.getFinishedNumber()+1);
            }
            activityService.updateActivity(activity);
        }

        return BaseResult.success(luckyCardId);
    }

    //前台显示剩余的抽卡次数
    @GetMapping(value = "/remainTimes/{activity_id}")
    @ResponseBody
    public BaseResult getRemainTimesByAcId(@PathVariable int activity_id){
        //获取用户ID
        String token = TokenUtil.getRequest().getHeader("Authorization");// 从 http 请求头中取出 token
        Integer user_id = userTokenMapper.getByToken(token).getUserId();
        int remainTimes = activeActivityService.getRemainTimes(user_id,activity_id);
        if(remainTimes <0 ){
            //新用户首次查询设置剩余次数为-1
            activeActivityService.addUserByActivityId(user_id,activity_id);
            Activity activity = activityService.getById(activity_id);
            //更新活动参与人数的状态
            if (activity.getJoinedNumber()== null){
                activity.setJoinedNumber(1);
            }else{
                activity.setJoinedNumber(activity.getJoinedNumber()+1);
            }
            activityService.updateActivity(activity);
            return BaseResult.success("首次参与活动，即可获得3次刮卡机会！");
        }
        return BaseResult.success(remainTimes);
    }
    @GetMapping(value = "/searchScratchLog/{activity_id}")
    @ResponseBody
    public BaseResult searchScratchLog(@PathVariable int activity_id){

        String token = TokenUtil.getRequest().getHeader("Authorization");// 从 http 请求头中取出 token
        Integer user_id = userTokenMapper.getByToken(token).getUserId();
        List<ScratchCardLog> cardLogs = scratchCardLogService.findByUserAndActivity(user_id,activity_id);
        HashMap<String,Object> map= new HashMap<>();
        map.put("card_logs",cardLogs);
        List<Card> myCardList = new ArrayList<>();
        for(ScratchCardLog log: cardLogs){
            Card card = cardService.getById(log.getCardId());
            myCardList.add(card);
        }
        map.put("my_cardList",myCardList);
        return BaseResult.success(map);
    }

    @GetMapping(value = "/scratchFlow/{activity_id}")
    @ResponseBody
    public BaseResult scratchFlow(@PathVariable int activity_id){
        String token = TokenUtil.getRequest().getHeader("Authorization");// 从 http 请求头中取出 token
        Integer user_id = userTokenMapper.getByToken(token).getUserId();
        List<ScratchFlow> scratchFlows = scratchFlowMapper.findByUserAndActivity(user_id,activity_id);
        if(scratchFlows.isEmpty()){
            return BaseResult.success("暂无刮卡流水记录！");
        }
        return BaseResult.success(scratchFlows);
    }

    /**
     * 获取好友助力流水列表
     * @param activityId
     * @return
     */

    @PostMapping(value = "/getActivityHelperFlows")
    @ResponseBody
    public BaseResult getActivityHelperFlows(@RequestParam(value = "activityId") Integer activityId){
        String token = TokenUtil.getRequest().getHeader("Authorization");// 从 http 请求头中取出 token
        Integer inviterId = userTokenMapper.getByToken(token).getUserId();
        try{
            List<HelperFlow> helperFlows = helperFlowMapper.findByUserAndActivity(inviterId,activityId);
            return BaseResult.success(helperFlows);
        }catch (Exception e){
            return BaseResult.failure(500,"获取好友助力流水列表失败");
        }

    }

    /**批量上下架
     *
     */
    @PostMapping(value ="/updateActivityListStatus")
    @ResponseBody
    public BaseResult updateActivityListStatus(@RequestParam("activity_idList") List<Integer> activity_idList) {
        try{
            activityService.updateActivityListStatus(activity_idList);
            return BaseResult.success("批量修改上下架状态成功");
        }catch (Exception e){
            return BaseResult.failure(500,"批量修改在线状态失败");
        }
    }


    /**逐个上下架
     *
     */
    @GetMapping(value ="/updateActivityStatus/{activity_id}")
    @ResponseBody
    public BaseResult updateActivityStatus(@PathVariable int activity_id) {
        try{
            activityService.updateActivityStatus(activity_id);
            return BaseResult.success("修改上下架状态成功");
        }catch (Exception e){
            return BaseResult.failure(500,"修改活动状态失败");
        }
    }



}
