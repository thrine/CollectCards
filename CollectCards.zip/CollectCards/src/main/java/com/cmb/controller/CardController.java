package com.cmb.controller;

import com.cmb.dal.dao.UserTokenMapper;
import com.cmb.dal.entity.Card;
import com.cmb.dal.entity.ScratchCardLog;
import com.cmb.model.BaseResult;
import com.cmb.service.ActiveActivityService;
import com.cmb.service.CardService;
import com.cmb.service.ScratchCardLogService;
import com.cmb.util.TokenUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;

/**
 * @author lingjieshi
 * @version 1: CardController.java, v 0.1 2020/8/20 1:24 上午  lingjieshi Exp $
 */
@RestController
@RequestMapping(value = "/card")
public class CardController {

    @Autowired
    CardService cardService;
    @Autowired
    ActiveActivityService activeActivityService;
    @Autowired
    ScratchCardLogService scratchCardLogService;
    @Autowired
    UserTokenMapper userTokenMapper;

    /**点击获取某个在线卡片的详情
     *
     */
    @GetMapping(value = "/cardDetail/{cardId}")
    @ResponseBody
    public BaseResult getActivityDetail(@PathVariable int cardId){
        Card card=cardService.getById(cardId);
        return BaseResult.success(card);
    }

    /**
     * 与活动ID相连接的相关卡片信息的请求
     */
    @GetMapping(value = "/getActivityCards/{activityId}")
    @ResponseBody
    public BaseResult<Object> getActivityCards(@PathVariable int activityId){
        List<Card> cardList =cardService.getFiveCardsByActivityId(activityId);
        if(cardList == null || cardList.size()!=5){
            return BaseResult.failure(400,"后台卡片信息异常！");
        }
        //返回该活动的卡片信息和该用户的抽卡情况信息、抽卡记录
        HashMap<String,List> response = new HashMap<>();
        response.put("activity_cards",cardList);

        String token = TokenUtil.getRequest().getHeader("Authorization");// 从 http 请求头中取出 token
        Integer user_id = userTokenMapper.getByToken(token).getUserId();

        List<ScratchCardLog> cardLogs = scratchCardLogService.findByUserAndActivity(user_id,activityId);
        response.put("user_cards",cardLogs);
        if(cardLogs.size()==5){
            BaseResult.success("您已经集卡完成！");
        }
        //已经集满的话修改complete状态位为1
//        if(viewList.size() == 5){
//            activeActivityService.updateCompleteStatus(user_id,1);
//        }
        //放入用户抽卡记录信息，按时间降序排列
       // List<ScratchCardLog> logs2 = scratchCardLogService.findByUserAndActivity(user_id,activityId);
        return BaseResult.success(response);
    }
}
