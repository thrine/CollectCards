package com.cmb.controller;

import java.sql.Connection;

import com.alibaba.fastjson.JSON;

import com.cmb.dal.entity.UserTest;
import com.cmb.model.BaseResult;
import com.cmb.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.DigestUtils;
import org.springframework.web.bind.annotation.*;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.GetMapping;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Map;

/**
 * @author lingjieshi
 * @version 1: UsersController.java, v 0.1 2020/8/16 1:19 下午  lingjieshi Exp $
 */
@RestController
@RequestMapping("/user")
public class UsersController {

    @Autowired
    private UserService userService;

    @GetMapping("/findAll")
    public List<UserTest> findAll() {
        return userService.getUserList();
    }

//    @GetMapping("/hello")
//    public String test(HttpServletRequest request) {
//        String token = request.getHeader("token");
//        JWTResult result = JWTUtils.checkToken(token);
//        Integer userId = result.getUserId();
//    }

    @GetMapping(value = "/userList")
    public ResponseEntity<Map<String, Object>> getUserList(@RequestParam Map<String, String> params) {
        List<UserTest> AllUsers = userService.getUserList();
        return new ResponseEntity(AllUsers, HttpStatus.OK);
    }

    /**
     *用户注册，在service中判断
     */
    @PostMapping(value ="/register")
    @ResponseBody
    public BaseResult<UserTest> register(@RequestBody UserTest user) {
        return userService.addUser(user);
    }

    /**
     *用户登录，在service中判断
     */
    @PostMapping(value ="/login")
    @ResponseBody
    public BaseResult userLogin(@RequestBody UserTest user, HttpServletResponse response) {
        return userService.userLogin(user);
    }

    /**
    *用户注销
     */
    @PostMapping(value = "/logout")
    public BaseResult userLogout(){
        return BaseResult.success(null);
    }

    @PostMapping(value = "/updateUser")
    public BaseResult updateUser(@RequestBody UserTest user){
        try {
            int res = userService.updateUser(user);
            return BaseResult.success(res);
        } catch (Exception e){
            e.printStackTrace();
            return BaseResult.defaultFailure();
        }
    }

    @PostMapping(value = "/userLogin")
    public String login(HttpServletRequest request, HttpSession session){
        String userName = request.getParameter("name");
        String password = request.getParameter("password");
        if(null == userName || null == password){
            return "redirect:/user/findAll";
        }
        String md5Password = DigestUtils.md5DigestAsHex(password.getBytes());
        UserTest user = userService.login(userName,md5Password);
        if (null == user){
            request.setAttribute("message","用户名或密码错误");
            return "userLogin";
        }
        // 用户已登录, 保存用户名, 跳转到前台首页
        session.setAttribute("user",user);
        return "redirect:/activityList";
    }

    @PostMapping(value = "user/register2")
    public ResponseEntity<Map<String, Object>> getCaseList(@RequestParam Map<String, String> param){
        UserTest user = new UserTest();
        user.setName(param.get("name"));
        user.setPassword(param.get("password"));
        user.setNickname(param.get("nickname"));
        user.setSex(param.get("sex"));
        user.setTelephone(param.get("telephone"));
        //对密码进行 md5 加密
        String md5Password = DigestUtils.md5DigestAsHex(user.getPassword().getBytes());
        user.setPassword(md5Password);
        userService.addUser(user);
        UserTest newUser = userService.FindByName(user.getName());
        return new ResponseEntity(newUser, HttpStatus.OK);
    }


   }
