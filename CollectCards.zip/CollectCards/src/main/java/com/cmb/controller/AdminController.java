package com.cmb.controller;

/**
 * @author lingjieshi
 * @version 1: AdminController.java, v 0.1 2020/8/14 3:04 下午  lingjieshi Exp $
 */


import com.cmb.dal.dao.UserTokenMapper;
import com.cmb.dal.entity.Activity;
import com.cmb.dal.entity.Admin;
import com.cmb.dal.entity.Card;
import com.cmb.model.BaseResult;
import com.cmb.service.ActivityService;
import com.cmb.service.AdminService;
import com.cmb.service.CardService;
import com.cmb.service.UserService;
////import com.github.pagehelper.PageHelper;
////import com.github.pagehelper.PageInfo;

import com.cmb.util.TokenUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
//
/*
 * 管理员控制器
 * */
@RestController
@RequestMapping(value = "/admin")
public class AdminController {

    @Autowired
    AdminService adminService;
    @Autowired
    UserService userService;
    @Autowired
    ActivityService activityService;
    @Autowired
    CardService cardService;
    @Autowired
    UserTokenMapper userTokenMapper;

    /**
     * 登陆验证
     */
      @PostMapping(value = "/login")
      @ResponseBody
      public BaseResult adminLogin(@RequestBody Admin admin){
          return adminService.adminLogin(admin.getName(),admin.getPassword());
      }

    //添加活动及卡片
    @PostMapping(value = "/addActivity")
    @ResponseBody
    public BaseResult addActivity(@RequestBody Activity activity){
          String token = TokenUtil.getRequest().getHeader("Authorization");// 从 http 请求头中取出 token
          String creator  = userTokenMapper.getByToken(token).getUserName();//取出创建人名称
          activity.setCreator(creator);
          activity.setCreateDate( new Date());
          return activityService.addActivity(activity);
    }

    //添加卡片列表 @RequestParam HashMap param
    @PostMapping(value = "/addCardListByActivity")
    @ResponseBody
    public BaseResult addCardListByActivity(@RequestParam(value = "cardList") List<Card> cardList,
                                        @RequestParam(value = "activityId") Integer activityId){
          if (cardList.size() != 5){
              return BaseResult.failure(405,"添加活动卡片不符合5张限额");
          }
        for(Card card:cardList){
            card.setActivityId(activityId);
            BaseResult res = cardService.addCard(card);
            if(res.getSuccess() == false){
                //删掉所有列表中的卡片，然后删掉活动
                cardService.deleteCardByActivity(activityId);
                return BaseResult.failure(400,"添加活动卡片失败");
            }
        }
        return BaseResult.success("活动卡片列表添加成功");
    }

    //活动卡片列表
    @GetMapping(value = "/getFiveCardsByActivityId/{id}")
    @ResponseBody
    public BaseResult getFiveCardsByActivityId(@PathVariable int id){
        List<Card> cardList = cardService.getFiveCardsByActivityId(id);
        if(cardList.isEmpty()){
            return BaseResult.defaultFailure();
        }else{
            return BaseResult.success(cardList);
        }
    }

    //编辑活动
    @PostMapping(value = "/updateActivity")
    @ResponseBody
    public BaseResult updateActivity(@RequestBody Activity activity){
        if(activity == null){
            return BaseResult.failure(500,"编辑活动失败");
        }else{
            return activityService.updateActivity(activity);
        }
    }

    @GetMapping(value = "/deleteActivity/{activityId}")
    @ResponseBody
    public BaseResult deleteActivity(@PathVariable int activityId){
          try{
              activityService.deleteActivity(activityId);
              return BaseResult.success("删除活动成功！");
          }catch (Exception e){
              return BaseResult.failure(500,"活动删除失败");
          }
    }
    @GetMapping(value = "/deleteCard/{cardId}")
    @ResponseBody
    public BaseResult deleteCard(@PathVariable int cardId){
          try{
              cardService.deleteCard(cardId);
              return BaseResult.success("删除卡片成功！");
          }catch (Exception e){
              return BaseResult.failure(500,"卡片删除失败");
          }

    }
    //添加
    @PostMapping(value = "/addCardByActivityAndCardList")
    @ResponseBody
    public BaseResult addCardByActivityAndCardList(@RequestParam(value = "cardList") List<Card> cardList,
                                                   @RequestParam(value = "activity") Activity activity){
        if (cardList.size() != 5){
            return BaseResult.failure(405,"添加活动卡片不符合5张限额");
        }
        for(Card card:cardList){
            card.setActivityId(activity.getId());
            BaseResult res = cardService.addCard(card);
            if(res.getSuccess() == false){
                //删掉所有列表中的卡片，然后删掉活动
                cardService.deleteCardByActivity(activity.getId());
                return BaseResult.failure(400,"添加活动卡片失败");
            }
        }
        return BaseResult.success("活动卡片列表添加成功");
    }

    @RequestMapping(value = "/addActivityAndCards",method = RequestMethod.POST)
    @ResponseBody
    public BaseResult addActivityAndCards(@RequestBody HashMap activityAndCards){
        List<Card> cardList= (List<Card>) activityAndCards.get("card_list");
        Activity activity = (Activity) activityAndCards.get("activity");
        Date date = new Date();
        activity.setCreateDate(date);
        int respCode = activityService.addActivity(activity).getCode();
        if(respCode != 200){
            return BaseResult.failure(400,"添加活动失败");
        }
        int activity_id = activity.getId();
        for(Card card:cardList){
            card.setActivityId(activity_id);
            //添加事务 异常处理 数据一致性
            if(cardService.addCard(card).getCode() != 200 ){
                //删掉所有列表中的卡片，然后删掉活动
                cardService.deleteCardByActivity(activity_id);
                activityService.deleteActivity(activity_id);
                return BaseResult.failure(400,"添加活动卡片失败");
            }
        }
        return BaseResult.success("添加成功！");
    }

    //添加卡片
    @PostMapping(value = "/addCardByActivity")
    @ResponseBody
    public BaseResult addCardByActivity(@RequestBody Card card){
        List<Card> cardList = cardService.getFiveCardsByActivityId(card.getActivityId());
        if(cardList.isEmpty()){
            return cardService.addCard(card);
        }
        if (cardList.size() < 5){
            double sumProbability = 0;
            for(Card checkCard : cardList){
               sumProbability = sumProbability + checkCard.getProbability();
            }
            double sumNow = sumProbability +card.getProbability();
            if( sumNow > 1){
                return BaseResult.failure(405,"活动的卡片概率和不能超过1");
            } else
                return cardService.addCard(card);
        }else if (cardList.size() == 5){
            return BaseResult.failure(400,"每个活动的卡片限额为5张");
        }
        return BaseResult.failure(400,"每个活动的卡片限额为5张");
    }

    @PostMapping(value = "/updateCardByActivity")
    @ResponseBody
    public BaseResult updateCardByActivity(@RequestBody Card card){
        if(card == null){
            return BaseResult.failure(404,"卡片内容无效");
        }
        List<Card> cardList = cardService.getFiveCardsByActivityId(card.getActivityId());
        Card oddCard = cardService.getById(card.getId());
        if (cardList.size() <= 5 && oddCard != null){
            double sum = 0;
            for(Card checkCard : cardList){
                sum = sum + checkCard.getProbability();
            }
            //去除旧概率，计算新概率和
            double sumNow = sum - oddCard.getProbability() + card.getProbability();
            if( sumNow > 1){
                return BaseResult.failure(405,"活动的卡片概率和不能超过1");
            } else {
                cardService.updateCard(card);
               return BaseResult.success("编辑卡片成功！");
            }
        }else
            return BaseResult.failure(400,"编辑卡片列表失败");
    }


    @RequestMapping(value = "/getActivityListByNameLike" , method = RequestMethod.GET)
    @ResponseBody
    public BaseResult getActivityListByNameLike(@RequestParam(value = "searchString") String searchString){
        List<Activity> activityList = activityService.getActivityListByLikeName(searchString);
        if(activityList.isEmpty()){
            return BaseResult.failure(400,"暂无符合该活动名称的查询结果");
        }else
        return BaseResult.success(activityList);
    }


    @RequestMapping(value = "/getActivityListByCreateTime" , method = RequestMethod.GET)
    @ResponseBody
    public BaseResult getActivityListByCreateTime(@RequestParam(value = "time") String startTime) throws ParseException {
        startTime = startTime.replace("GMT", "").replaceAll("\\(.*\\)", "");
        SimpleDateFormat format =  new SimpleDateFormat("EEE MMM dd yyyy hh:mm:ss z", Locale.ENGLISH);
        Date date = format.parse(startTime);
        List<Activity> activityList = activityService.getActivityByCreateTime(date);
        if(activityList.isEmpty()){
            return BaseResult.failure(400,"暂无该时间点后的创建的活动");
        } else
        return BaseResult.success(activityList);
    }



}

