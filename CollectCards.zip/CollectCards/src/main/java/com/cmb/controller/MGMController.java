package com.cmb.controller;

import com.cmb.dal.dao.HelperFlowMapper;
import com.cmb.dal.dao.UserTokenMapper;
import com.cmb.dal.entity.ActiveActivity;
import com.cmb.dal.entity.Activity;
import com.cmb.dal.entity.HelperLog;
import com.cmb.model.BaseResult;
import com.cmb.model.HelperFlow;
import com.cmb.service.ActiveActivityService;
import com.cmb.service.ActivityService;
import com.cmb.service.HelperLogService;
import com.cmb.service.UserService;
import com.cmb.util.TokenUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

/**
 * @author lingjieshi
 * @version 1: MGMController.java, v 0.1 2020/8/20 1:35 上午  lingjieshi Exp $
 */
@RestController
@RequestMapping(value = "/share")
public class MGMController {

        @Autowired
        HelperLogService helperLogService;
        @Autowired
        UserService userService;
        @Autowired
        ActivityService activityService;
        @Autowired
        HelperFlowMapper helperFlowMapper;
        @Resource
        ActiveActivityService activeActivityService;
        @Autowired
        UserTokenMapper userTokenMapper;

//获取为该发起人助力的好友助力列表
    @PostMapping(value = "/getHelpers")
    @ResponseBody
    public BaseResult getActivityHelpers(@RequestParam(value = "inviterId") Integer inviterId,
                                         @RequestParam(value = "activityId") Integer activityId){
        List<HelperLog> helperLogs = helperLogService.getHelperByActivity(inviterId,activityId);
        return BaseResult.success(helperLogs);
    }

        @GetMapping(value = "/fetchShareInfo")
        @ResponseBody
        public BaseResult<HashMap<String,Object>> fetchShareInfo(@RequestParam(value = "inviterName") String inviterName,
                                                                 @RequestParam(value = "activityId") Integer activity_id){
            String token = TokenUtil.getRequest().getHeader("Authorization");// 从 http 请求头中取出 token
            Integer helper_id = userTokenMapper.getByToken(token).getUserId();
            int inviter_id = userService.FindByName(inviterName).getId();
            String inviter_nickName = userService.FindByName(inviterName).getNickname();
            HashMap<String,Object> map= new HashMap<>();
            //我（助力人）为其助力的次数
            HelperLog oddHelperLog  = helperLogService.getCountByUserHelperActivity(inviter_id,helper_id,activity_id);
            if(oddHelperLog == null){
                map.put("help_count",0);
            }else{
                int remainTimes = oddHelperLog.getRemainTimes();
                map.put("help_count",3-remainTimes);
            }

            /**
             * 为其助力的朋友们助力列表
             */
            List<HelperFlow> helperFlows = helperFlowMapper.findByUserAndActivity(inviter_id,activity_id);
            if(helperFlows.isEmpty()){
                map.put("helper_list",null);
            }else{
                map.put("helper_list",helperFlows);
            }

            /**
             * 获得活动信息
             */
            Activity activity =activityService.getById(activity_id);
            map.put("activity_info",activity);
            map.put("inviter_nickName",inviter_nickName);
            return BaseResult.success(map);
        }


        @PostMapping(value = "/helpFriend")
        @ResponseBody
        public BaseResult helpFriend(@RequestParam(value = "inviterName") String inviterName,
                                 @RequestParam(value = "activityId") Integer activity_id){
            String token = TokenUtil.getRequest().getHeader("Authorization");// 从 http 请求头中取出 token
            Integer helper_id = userTokenMapper.getByToken(token).getUserId();
            int inviter_id = userService.FindByName(inviterName).getId();
            if(helper_id == inviter_id )
                return BaseResult.failure(500,"不允许给自己助力哦！！");
            /**
             * 根据ID们查找助力记录、参与活动记录
             */
            HelperLog oddHelperLog = helperLogService.getCountByUserHelperActivity(inviter_id,helper_id,activity_id);
           //为其助力过的朋友们
            List<HelperLog> helperLogs = helperLogService.getHelperByActivity(inviter_id,activity_id);
            ActiveActivity activeActivity = activeActivityService.getActiveLogByUserAndActivityId(inviter_id, activity_id);
            /**
             * 新助力的朋友，添加助力表helperLog记录，同1位朋友最多助力3次，所以设定剩余助力次数为2
             * 首次分享+2次助力机会
             */
            int count = 0;
            if(helperLogs.isEmpty()){
                count=1;
            }
            if(oddHelperLog == null) {
                HelperLog helperLog = new HelperLog();
                helperLog.setActivityId(activity_id);
                helperLog.setUserId(inviter_id);
                helperLog.setHelperId(helper_id);
                helperLog.setRemainTimes(2);
                int record = helperLogService.addHelpLog(helperLog);

                /**
                 * 未助力过，则新增助力流水
                 */
                HelperFlow helperFlow = new HelperFlow();
                helperFlow.setGetTime(new Date());
                helperFlow.setActivityId(activity_id);
                helperFlow.setInviterId(inviter_id);
                helperFlow.setActivityName(activityService.getById(activity_id).getName());
                helperFlow.setInviterNickname(userService.FindById(inviter_id).getNickname());
                helperFlow.setHelperNickname(userService.FindById(helper_id).getNickname());
                helperFlowMapper.insertSelective(helperFlow);

                /**
                 * 为发起人更新剩余刮卡次数
                 */
                activeActivity.setRemainTimes(activeActivity.getRemainTimes() + 1 + count);
                activeActivityService.updateActiveActivity(activeActivity);
                return BaseResult.success("助力成功！");

            }else{
                /**
                 * 一个朋友只能助力3次
                 */
                if(oddHelperLog.getRemainTimes() == 0){
                    return BaseResult.failure(500,"助力次数已满!该活动最多给一位朋友助力3次哦！");
                }
                /**
                 * 老朋友则减一次助力次数
                 */
                oddHelperLog.setRemainTimes(oddHelperLog.getRemainTimes()-1);
                helperLogService.updateHelperLog(oddHelperLog);


                /**
                 * 只要助力次数小于3，新增助力流水
                 */
                HelperFlow helperFlow = new HelperFlow();
                helperFlow.setGetTime(new Date());
                helperFlow.setActivityId(activity_id);
                helperFlow.setInviterId(inviter_id);
                helperFlow.setActivityName(activityService.getById(activity_id).getName());
                helperFlow.setInviterNickname(userService.FindById(inviter_id).getNickname());
                helperFlow.setHelperNickname(userService.FindById(helper_id).getNickname());
                helperFlowMapper.insertSelective(helperFlow);

                /**
                 * 为发起人更新剩余刮卡次数
                 */
                activeActivity.setRemainTimes(activeActivity.getRemainTimes() + 1 + count);
                activeActivityService.updateActiveActivity(activeActivity);
                return BaseResult.success("助力成功！");
            }

        }
    }
