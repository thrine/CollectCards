//package com.cmb.util;
//
//
//import org.springframework.http.HttpRequest;
//
//import java.net.Inet4Address;
//import java.net.InetAddress;
//import java.net.NetworkInterface;
//import java.util.Enumeration;
//import java.util.Map;
//
///**
// * @author lingjieshi
// * @version 1: HttpRequestUtil.java, v 0.1 2020/8/18 11:09 上午  lingjieshi Exp $
// */
//public class HttpRequestUtil {
//
//    public static String post(String url, Map<String, String> params) {
//
//        HttpRequest request = null;
//        if (params.isEmpty()) {
//            request = HttpRequest.post(url);
//        } else {
//            request = HttpRequest.post(url).form(params);
//        }
//        return request.body();
//    }
//
//    public static String get(String url, Map<String, String> params) {
//        HttpRequest request = null;
//        if (params.isEmpty()) {
//            request = HttpRequest.get(url);
//        } else {
//            request = HttpRequest.get(url).form(params);
//        }
//        return request.body();
//    }
//
//    public static String getHostIp() {
//        try {
//            Enumeration<NetworkInterface> allNetInterfaces = NetworkInterface.getNetworkInterfaces();
//            while (allNetInterfaces.hasMoreElements()) {
//                NetworkInterface netInterface = (NetworkInterface)allNetInterfaces.nextElement();
//                Enumeration<InetAddress> addresses = netInterface.getInetAddresses();
//                while (addresses.hasMoreElements()) {
//                    InetAddress ip = (InetAddress)addresses.nextElement();
//                    if (ip instanceof Inet4Address
//                            && !ip.isLoopbackAddress() //loopback地址即本机地址，IPv4的loopback范围是127.0.0.0 ~ 127.255.255.255
//                            && !ip.getHostAddress().contains(":")) {
//                        return ip.getHostAddress();
//                    }
//                }
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return null;
//    }
//
//}
