package com.cmb.util;


import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.cmb.dal.entity.UserTest;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * @author lingjieshi
 * @version 1: TokenUtil.java, v 0.1 2020/8/18 9:40 上午  lingjieshi Exp $
 */
public class TokenUtil {

    public static String generateToken() {
        return UUID.randomUUID().toString().replace("-", "");
    }

    public static int getTokenUserId() {
        String token = getRequest().getHeader("Authorization");// 从 http 请求头中取出 token
        String userId = JWT.decode(token).getAudience().get(0);
        return Integer.parseInt(userId);
    }

    private static final String TOKEN_SECRET = "JNVCOR&$@)_(#VSZ+_?CV}{XNVM^&";  // 设置签名私钥
    /**
     * 生成token，可以将你认为需要的数据当成参数存入
     */
    public static String generateToken(UserTest user) {
        try {
            Date date = new Date(System.currentTimeMillis());
            // 私钥和加密算法
            com.auth0.jwt.algorithms.Algorithm algorithm = Algorithm.HMAC256(TOKEN_SECRET);
            // 设置头部信息
            Map<String, Object> header = new HashMap<String, Object>(2);
            header.put("Type", "Jwt");
            header.put("alg", "HS256");
            // 返回token字符串
            return JWT.create()
                    .withAudience(user.getId().toString())
                    .withHeader(header)
                    .withClaim("role","user")
                    .withClaim("userName", user.getName())
                    .withClaim("password", user.getPassword())
                    .sign(algorithm);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    public static HttpServletRequest getRequest() {
        ServletRequestAttributes requestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        return requestAttributes == null ? null : requestAttributes.getRequest();
    }

//    public static int getTokenUserId() {
//        String token = getRequest().getHeader("Authorization");// 从 http 请求头中取出 token
//        String userId = JWT.decode(token).getAudience().get(0);
//        return Integer.parseInt(userId);
//    }

//
//    /**
//     * 生成token，可以将你认为需要的数据当成参数存入
//     */
//    public static String generateToken(UserTest user) {
//        try {
//
//            // 私钥和加密算法
//            Algorithm algorithm = Algorithm.HMAC256(TOKEN_SECRET);
//            // 设置头部信息
//            Map<String, Object> header = new HashMap<String, Object>(2);
//            header.put("Type", "Jwt");
//            header.put("alg", "HS256");
//            // 返回token字符串
//            return JWT.create()
//                    .withAudience(user.getUserId().toString())
//                    .withHeader(header)
//                    .withClaim("role","user")
//                    .withClaim("userName", user.getUserName())
//                    .withClaim("password", user.getPassword())
//                    .sign(algorithm);
//        } catch (Exception e) {
//            e.printStackTrace();
//            return null;
//        }
//    }


}
