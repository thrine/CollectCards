package com.cmb.util;

import com.cmb.dal.entity.Card;
import com.cmb.model.CardOffset;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.*;

/**
 * @author lingjieshi
 * @version 1: ScratchCardUtil.java, v 0.1 2020/8/18 3:44 下午  lingjieshi Exp $
 */
public class ScratchCardUtil {

    /**
     * 计算自身相对于总体的比例
     *
     * @param selfAmount 自身
     * @param all  总体
     * @return 比例
     */
    public static double getPercent(Integer selfAmount, Integer all) {
        // 比例计算出来会有很多小数，为了看得清晰，要四舍五入一下
        return new BigDecimal(selfAmount / all.floatValue()).setScale(2, BigDecimal.ROUND_HALF_UP).floatValue();
    }

    /**
     * 四舍五入把double转化为int类型整数,0.5也舍去,0.51进一
     * @param selfPercent
     * @return
     */
    public static int getAmountInt(double selfPercent, Integer all){
        double amount = selfPercent * all;
        DecimalFormat df = new DecimalFormat("######0"); //四色五入转换成整数
        return Integer.parseInt(df.format(amount));
    }

    /**
     * 根据比例，在100之间计算出区间跨度，进一步来计算中奖区间
     *
     * @param percent 比例
     * @return 跨度
     */
    private static int getRandom(double percent) {
        // Percent需要在这里四舍五入
        return new BigDecimal(percent * 100).intValue();
    }

    public static Map<Integer, CardOffset> lotterySpan(Integer allAmount, List<Card> cardList) {
        // double emptyProbability = 1-cardsList.;
        //List<Card> cards = new ArrayList<>();
        //for(Card)
        Integer index = 0;
        double originProbabilitySum = 0;
        for (index = 0; index < cardList.size(); index++) {
            originProbabilitySum = originProbabilitySum + cardList.get(index).getProbability();
        }
        double emptyProbability = 1 - originProbabilitySum;

        cardList.add(new Card(-1, "没抽中", emptyProbability));

        Map<Integer, CardOffset> CardOffsetMap = new HashMap<>();
        int amount;// 配置额度
        int span;// 跨度
        int start = 0;// 区间开始
        int end;// 区间结束
        for (Card card : cardList) {
            amount = getAmountInt(card.getProbability(), allAmount);
            span = getRandom(card.getProbability());
            // 按照跨度计算cardOffset
            end = start + span;
            CardOffsetMap.put(card.getId(), new CardOffset(card.getProbability(), span, start, end, amount));
            // 区间设定为100，所以每次都需要用新的数值+跨度
            start = end;
        }
        return CardOffsetMap;
    }
//        //log
//        for (Integer CardId : CardOffsetMap.keySet()) {
//            CardOffset offset = CardOffsetMap.get(CardId);
//           // System.out.println("卡片: " + CardId + ", 配额: " + offset.getAmount() + ", 占比: " + offset.getPercent() + ", 跨度: " + offset.getSpan() + ", 区间: [" + offset.getStart() + ", " + offset.getEnd() + ")");
//        }
        /**
         * 计算每个极限抽完卡池中某个卡片种类的情况，如果存量为0，则自动递归（即进入下一次抽卡）
         * 已经考虑轮空的概率
         * 计算每个卡片被抽中的次数，该数量不可超过卡池中的卡片总数
         *
         */
        public static Map<Integer, Integer> countCards(Integer allAmount,Map<Integer, CardOffset> CardOffsetMap){
        Map<Integer, Integer> countMap = new HashMap<>();
        //卡片ID
        Integer CardId;
        //临时存储卡片数量
        Integer num;
        for (int i = 0; i < allAmount; i++) {
            // 由于这里是递归处理，所以如果最后为null了，说明已经到达了所有卡片的配额上限（奖品或者抽奖次数用完了）
            CardId = scratchCard(CardOffsetMap);
            if (CardId == null) {
                break;
            }
            // 记录每个卡片的中标次数，达到上限了就排除掉
            num = countMap.get(CardId);
            if (num != null) {
                countMap.put(CardId, num + 1);
            } else {
                countMap.put(CardId, 1);
            }
            // 次数到了上限，移除卡片（可看做：中奖之后移除卡片）
            if (countMap.get(CardId) >= CardOffsetMap.get(CardId).getAmount()) {
                CardOffsetMap.remove(CardId);
            }
        }
//        // log
//        for (Integer key : countMap.keySet()) {
//            System.out.println("卡片1"+key + "被抽中了" + countMap.get(key) + "次，概率: " + getPercent(countMap.get(key), allAmount));
//        }
        return countMap;

    }

    /**
     * 按照计算好的区间，转动圆盘（即区间[0,100)）获取卡片（即视为抽中相应卡片）
     *
     * @param CardOffsetMap 卡片offset信息
     * @return 抽中的卡片
     */
    public static Integer select(Map<Integer, CardOffset> CardOffsetMap) {
        // 计算一个随机数值，看其散列在哪个卡片的区间
        int selectNum = new Random().nextInt(100);
        CardOffset offset;
        // 由于要兼顾每一张卡片，所以需要循环（效率待定？）
        for (Integer CardId : CardOffsetMap.keySet()) {
            offset = CardOffsetMap.get(CardId);
            // 100以内产生随机生成数，区间左侧需要包括，右侧不包括
            if (offset.getStart() <= selectNum && selectNum < offset.getEnd()) {
                return CardId;
            }
        }
        return null;
    }

    /**
     * 选中之后，会排除掉部分卡片，递归调用，将机会让给别的卡
     *
     * @param CardOffsetMap 卡片offset信息
     * @return 选中的卡片
     */
    public static Integer scratchCard(Map<Integer, CardOffset> CardOffsetMap) {
        Integer CardId = select(CardOffsetMap);
        if (!CardOffsetMap.isEmpty() && CardId == null) {
            return scratchCard(CardOffsetMap);
        }
        return CardId;
    }



}
