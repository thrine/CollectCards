package com.cmb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author lingjieshi
 * @version 1: Application.java, v 0.1 2020/8/12 1:59 下午  lingjieshi Exp $
 */
//SpringBoot项目启动类
@SpringBootApplication
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}
